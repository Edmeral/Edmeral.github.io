<?php
	require_once 'models/statistiques.php';
	$page_stat = true;
	$s = "";

	$max_year = stat_year('MAX');
	$min_year = stat_year('MIN');

	$stats = array();

	for($i = $min_year; $i <= $max_year; $i++)
	{
		$stats[$i]['y'] = $i;
		$stats[$i]['p'] = stat_get_num('journal', $i);
		$stats[$i]['t'] = stat_get_num('these', $i);
		$stats[$i]['h'] = stat_get_num('HDR', $i);
		$stats[$i]['b'] = stat_get_num('brevet', $i);
		$stats[$i]['a'] = stat_get_num('autre', $i);
	}

	$total_pub = stat_get_num('all', $min_year);
	$total_membres = stat_get_membres();
	$total_ev = stat_get_activites();