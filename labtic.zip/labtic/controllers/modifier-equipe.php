<?php 
	session_start();
	require "inc/connexion.php";
	
	$db = connexion();

	$id_equipe = $_POST['equipe_id'];
	$libelle = $_POST['libelle'];
	$theme = utf_encode($_POST['theme']);
	$description = utf_encode($_POST['description']);
	$responsable = $_POST['responsable'];

	$q = 'UPDATE equipes SET  libelle = ?,description = ?,theme = ?,id_responsable = ? WHERE equipe_id = ?';
	$req = $db->prepare($q);
	$req->execute(array($libelle, $description, $theme, $responsable, $id_equipe));

	$db->query('UPDATE membres SET equipe = '.$id_equipe.' WHERE membre_id = '.$responsable);

	if(isset($_FILES['photo-logo']) && $_FILES['photo-logo']['name']!="") 
	{	
		$extensions_valides = 'jpg' ;
		$extension_upload = strtolower(  substr(  strrchr($_FILES['photo-logo']['name'], '.')  ,1) );
		if($extension_upload==$extensions_valides)
		{
			$nom="assets/images/equipes/photo_logo_{$id_equipe}.jpg";
			$resultat = move_uploaded_file($_FILES['photo-logo']['tmp_name'],$nom);					 
		}
		else
		{
			$error ="Erreur dans l'upload de l'image !";
			$app->flash('error', $error);
			$app->redirect('/labtic/ajouter-equipe');
		}	
	}

	if(isset($_FILES['photo-plaquette']) && $_FILES['plaquette-logo']['name']!="") 
	{	
		$extensions_valides = 'jpg' ;
		$extension_upload = strtolower(  substr(  strrchr($_FILES['photo-plaquette']['name'], '.')  ,1) );
		if($extension_upload==$extensions_valides)
		{
			$nom="assets/images/equipes/plaquette_equipe_{$id_equipe}.jpg";
			$resultat = move_uploaded_file($_FILES['photo-plaquette']['tmp_name'],$nom);					 
		}
		else
		{
			$error ="Erreur dans l'upload de l'image !";
			$app->flash('error', $error);
			$app->redirect('/labtic/ajouter-equipe');
		}	
	}


	$app->flash('success', "Equipe modifiée avec succès !");
	$app->redirect('/labtic/equipes');

	var_dump($_POST);
	echo $q;
