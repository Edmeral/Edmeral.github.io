<?php 
	session_start() ; 
	require "inc/connexion.php";
	
	
  if(isset($_POST['experience']) && isset($_POST['description']) && isset($_POST['date_exp']))
  {  	
	$db = connexion() ; 

	$membre_id = $_SESSION['membre_id'];
	$experience = $_POST['experience']; 
	$description = $_POST['description'];
	$date_exp = $_POST['date_exp'];
	$date_fin_exp = $_POST['date_fin_exp'];

	$q = 'INSERT INTO experience(membre_id,experience,description,date_exp,date_fin_exp) VALUES (:membre_id,:experience,:description, :date_exp, :date_fin_exp)';
	$req = $db->prepare($q);
	$req->execute(array('membre_id' => $membre_id,'experience' => $experience,'description' => $description,'date_exp'=>$date_exp,'date_fin_exp'=>$date_fin_exp));
	$app->flash('success', "Expérience ajoutée avec succès !");
	$app->redirect('/labtic/experiences/'.$membre_id); 
  }	

