<?php

	require 'models/activites.php';

	$activites = get_activites();

	$a ="";
	foreach ($activites as $activite) {
	 	$a .="<tr>";
	 	$a .="<td>".utf8_encode($activite['titre'])."</td>";
	 	$a .= '<td>&nbsp;&nbsp;
					<a href = "modifier-activite/'.$activite['id_activite'].'" class="table-action-btn"><i class="md md-edit"></i></a>&nbsp;&nbsp;
					<a href = "supprimer-activite/'.$activite['id_activite'].'" class="table-action-btn"><i class="md md-close"></i></a></td>';
		$a .="</tr>";					
	 }
	$affichage =$a ;  