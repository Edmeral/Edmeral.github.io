<?php
	require "models/publications.php" ;
	$publications = get_all_publications_formatted('all');
	$date_min =  min_date();


	$min = (int) $date_min ; 
	$max = (int) date("Y") ;
	$s = "[";
	for ($i=$min; $i <= $max ; $i++) { 
		$a = get_count("journal",$i);
		$b = get_count("HDR",$i);
		$c = get_count("these",$i);
		$d = get_count("brevet",$i);
		$e = get_count("autre",$i);
		$s .= "{ y: '".$i."', a:".$a.", b: ".$b." ,c:".$c." ,d:".$d." ,e:".$e."},";

	}

	$s .= "]";
	$data = $s; 
?>
