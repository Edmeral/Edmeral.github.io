<?php

	require 'models/seminaires.php';

	$contenu = get_info_seminaire($id);



