<?php
	require 'models/activites.php';

	$contenu = get_info_seminaire($id);



