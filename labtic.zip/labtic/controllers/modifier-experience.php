<?php  
	session_start();
	require "models/experiences.php";

	if(isset($_POST['experience']) && isset($_POST['description']) && isset($_POST['date_exp']))
	{  	
		$db = connexion();

		$experience_id = $_POST['experience_id'];
		$experience = $_POST['experience']; 
		$description = $_POST['description'];
		$date_exp = $_POST['date_exp'];
		$date_fin_exp = $_POST['date_fin_exp'];

		$q = "UPDATE experience SET experience = :exp, description = :descr ";
		$q .= ",date_exp = :date_exp ,date_fin_exp = :date_fin WHERE experience_id = :experience_id";

		$req = $db->prepare($q);
		$req->execute(array('experience_id' => $experience_id,'exp' => $experience,'descr' => $description,'date_exp'=>$date_exp,'date_fin'=>$date_fin_exp));
		
		$app->flash('success', "Expérience modifiée avec succès.");
		$app->redirect('/labtic/experiences/'.$_SESSION['membre_id']); 
	}	

