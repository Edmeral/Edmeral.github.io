<?php
	require 'models/textes.php';
	$a_propos = '<p>'.get_a_propos().'</p>';