<?php
	require 'models/membres.php';
	require 'models/equipes.php';
	$liste_membres = get_liste_membres();
	$membre_par_ligne = 5;

	$s = '<table style="width:100%; text-align: center;">';
	$nbm = 0;
	foreach($liste_membres as $membre)
	{
		if($membre['statut'] == "Permanent")
		{
			$nbm++;
			if($nbm % $membre_par_ligne == 1) $s .= '<tr>';
			$s .= '<td><p><img src="/labtic/assets/images/membres/photo_'.$membre["membre_id"].'.jpg" width="100" class="img-thumbnail"></p>
					<p><a href="membre/'.$membre["membre_id"].'">'.$membre["nom"].' '.$membre["prenom"].'</a></p></td>';
			if($nbm % $membre_par_ligne == 0) $s .= '</tr>';
		}
		else
			continue;
	}
	$s .= '</table>';

	$permanents = $s;

	$liste_membres = get_liste_membres();
	$s = '<table style="width:100%; text-align: center;">';
	$nbm = 0;
	foreach($liste_membres as $membre)
	{
		if($membre['statut'] == "Non-permanent")
		{
			$nbm++;
			if($nbm % $membre_par_ligne == 1) $s .= '<tr>';
			$s .= '<td><p><img src="/labtic/assets/images/membres/photo_'.$membre["membre_id"].'.jpg" width="100" class="img-thumbnail"></p>
					<p><a href="membre/'.$membre["membre_id"].'">'.$membre["nom"].' '.$membre["prenom"].'</a></p></td>';
			if($nbm % $membre_par_ligne == 0) $s .= '</tr>';
		}
		else
			continue;
	}
	$s .= '</table>';

	$non_perm = $s;

	$liste_membres = get_liste_membres();
	$s = '<table style="width:100%; text-align: center;">';
	$nbm = 0;
	foreach($liste_membres as $membre)
	{
		if($membre['statut'] == "Ancien")
		{
			$nbm++;
			if($nbm % $membre_par_ligne == 1) $s .= '<tr>';
			$s .= '<td><p><img src="/labtic/assets/images/membres/photo_'.$membre["membre_id"].'.jpg" width="100" class="img-thumbnail"></p>
					<p><a href="membre/'.$membre["membre_id"].'">'.$membre["nom"].' '.$membre["prenom"].'</a></p></td>';
			if($nbm % $membre_par_ligne == 0) $s .= '</tr>';
		}
		else
			continue;
	}
	$s .= '</table>';

	$anciens = $s;
?>
