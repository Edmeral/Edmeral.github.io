<?php 
	session_start();
	require "inc/connexion.php";
	
	$num_mois = array('janvier' => 1, 'février' => 2, 'fevrier' => 2, 'mars' => 3, 'avril' => 4, 'mai' => 5, 'juin' => 6, 
	                  'juillet' => 7, 'aout' => 8, 'août' => 8, 'septembre' => 9, 'octobre' => 10, 'novembre' => 11, 'décembre' => 12, 
	                  'decembre' => 12);


	$db = connexion();

	$id_pub = $_POST['ID'];
	$titre = $_POST['titre'];
	$mois = $num_mois[strtolower($_POST['mois'])];
	$annee = $_POST['annee'];
	$lieu = $_POST['lieu'];
	$source = $_POST['source'];
	$type = $_POST['type'];
	$resume = $_POST['resume'];

	$q = 'UPDATE publications SET  titre = ?, mois_publication = ?, annee_publication = ?,lieu = ?, source_publication = ?, type = ?,
		  resume = ? WHERE id = ?';
	$req = $db->prepare($q);
	$req->execute(array($titre, $mois, $annee, $lieu, $source, $type, $resume, $id_pub));

	if(isset($_FILES['document']) && $_FILES['document']['name']!="")
    {
    $extensions_valides = 'pdf';
    $extension_upload = strtolower(  substr(  strrchr($_FILES['document']['name'], '.')  ,1) );
    if($extension_upload==$extensions_valides)
    {
      $nom="assets/publications/publication_{$id_pub}.pdf";
      $resultat = move_uploaded_file($_FILES['document']['tmp_name'],$nom);
    }
    else
    {
      $error ="Erreur dans l'upload du document !";
      echo "Erreur dans l'upload du fichier";
      $app->flash('error', $error);
      $app->redirect('/labtic/ajouter-publication');
    }
  }

	$app->flash('success', "Publication modifiée avec succès !");
	$app->redirect('/labtic/mes-publications');

	var_dump($_POST);
	echo $q;
