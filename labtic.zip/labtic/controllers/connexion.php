<?php
	session_start();
	require 'models/connexion.php';
	require 'models/inc/credentials.php';

	if(isset($_POST["login"]) && isset($_POST["pass"]) && $_POST["login"] != "" && $_POST["pass"] != "")
	{
		// Highly disturbing, should be redone
		if($_POST["login"] == ADMINLOGIN && $_POST["pass"] == ADMINPASS)
		{
			$_SESSION['membre_id'] = 0;
			$_SESSION['privilege'] = 'admin';
			$_SESSION['created'] = true;
			$app->redirect('/labtic/');
		}
		if(sha1($_POST["pass"]) == get_password($_POST["login"]))
		{
			$_SESSION['membre_id'] = get_membre_id($_POST["login"]);
			$_SESSION['privilege'] = 'membre';
			$_SESSION['created'] = true;
			$app->redirect('/labtic/');
		}
		else
		{
			$app->render('connexion.php', array("erreur" => "faux"));
		}
	}
	else
	{
		$app->render('connexion.php', array("erreur" => "vide"));
	}