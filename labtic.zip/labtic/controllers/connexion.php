<?php
	session_start();
	require 'models/connexion.php';
	require 'models/inc/credentials.php';

	if(isset($_POST["login"]) && isset($_POST["pass"]) && $_POST["login"] != "" && $_POST["pass"] != "")
	{
		// Highly disturbing, should be redone
		
		if(sha1($_POST["pass"]) == get_password($_POST["login"]))
		{
			if($_POST["login"] == "admin")
			{
				$_SESSION['membre_id'] = 0;
				$_SESSION['privilege'] = 'admin';
				$_SESSION['created'] = true;
				$app->redirect('/labtic/');
			}
			else if(get_membre_statut(get_membre_id($_POST["login"])) == "Permanent")
			{
				$_SESSION['membre_id'] = get_membre_id($_POST["login"]);
				$_SESSION['privilege'] = 'membre';
				$_SESSION['created'] = true;
				$app->redirect('/labtic/');
			}
			else
			{
				$app->render('connexion.php', array("erreur" => "ancien"));
			}
		}
		else
		{
			$app->render('connexion.php', array("erreur" => "faux"));
		}
	}
	else
	{
		$app->render('connexion.php', array("erreur" => "vide"));
	}