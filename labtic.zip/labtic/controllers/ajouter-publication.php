<?php
session_start();
require "inc/connexion.php";

$db=connexion();

echo var_dump($_POST);
echo var_dump($_FILES);

$num_mois = array('janvier' => 1, 'février' => 2, 'fevrier' => 2, 'mars' => 3, 'avril' => 4, 'mai' => 5, 'juin' => 6, 
                  'juillet' => 7, 'aout' => 8, 'août' => 8, 'septembre' => 9, 'octobre' => 10, 'novembre' => 11, 'décembre' => 12, 'decembre' => 12);

if (isset($_POST['titre']) && isset($_POST['annee']) && isset($_POST['type']) && isset($_POST['resume'])) {
  $q = 'INSERT INTO publications(titre, mois_publication, annee_publication, lieu, source_publication,type, resume, date_ajout) VALUES 
        ("'.$_POST['titre'].'","'
          .$num_mois[strtolower($_POST['mois'])].'","'
          .$_POST['annee'].'","'
          .$_POST['lieu'].'","'
          .$_POST['source'].'","'
          .$_POST['type'].'","'
          .$_POST['resume'].'", CURRENT_DATE)';
  $db->exec($q);
  $new_id = (int) ($db->query('SELECT MAX(id) n FROM publications')->fetch()['n']);

  // Handling the file
  if(isset($_FILES['document']) && $_FILES['document']['name']!="")
  {
    $extensions_valides = 'pdf';
    $extension_upload = strtolower(  substr(  strrchr($_FILES['document']['name'], '.')  ,1) );
    if($extension_upload==$extensions_valides)
    {
      $nom="assets/publications/publication_{$new_id}.pdf";
      $resultat = move_uploaded_file($_FILES['document']['tmp_name'],$nom);
    }
    else
    {
      $error ="Erreur dans l'upload du document !";
      echo "Erreur dans l'upload du fichier";
      $app->flash('error', $error);
      $app->redirect('/labtic/ajouter-publication');
    }
  }

  // Adding the auteurs actifs and auteurs passifs
  $auteursPassifs = (isset($_POST['auteursPassifs'])) ? $_POST['auteursPassifs'] : [];
  $auteursActives = (isset($_POST['auteursActives'])) ? $_POST['auteursActives'] : [];

  foreach($auteursPassifs as $aut) {
    if($aut == "")
      continue;
    $q = 'INSERT INTO publication_auteurs_passifs values("'.$new_id.'", "'.$aut.'")';
    $db->exec($q);
  }

  foreach($auteursActives as $aut) {
    $autId = intval($aut);
    $q = 'INSERT INTO publication_auteurs_actifs values("'.$new_id.'", '.$autId.')';
    $db->exec($q);
  }

  $app->flash('success', 'Publication ajouté avec succès');
  $app->redirect('/labtic/ajouter-publication');
}

else {
  $app->flash('error', 'Erreur dans le formulaire');
  $app->redirect('/labtic/ajouter-publication');
  }

