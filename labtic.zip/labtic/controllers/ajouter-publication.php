<?php

session_start() ;
require "inc/connexion.php";

$db=connexion();

echo var_dump($_POST);
echo var_dump($_FILES);

if (isset($_POST['titre']) && isset($_POST['annee']) && isset($_POST['type']) && isset($_POST['resume'])) {
  $q = 'INSERT INTO publications(titre, annee_publication, type, resume, date_ajout) VALUES 
        ("'.$_POST['titre'].'","'.$_POST['annee'].'","'.$_POST['type'].'","'.$_POST['resume'].'", CURRENT_DATE)';
  $db->exec($q);
  $new_id = (int) ($db->query('SELECT MAX(id) n FROM publications')->fetch()['n']);

  // Handling the file
  if(isset($_FILES['document']) && $_FILES['document']['name']!="")
  {
    $extensions_valides = 'pdf';
    $extension_upload = strtolower(  substr(  strrchr($_FILES['document']['name'], '.')  ,1) );
    if($extension_upload==$extensions_valides)
    {
      $nom="assets/publications/publication_{$new_id}.pdf";
      $resultat = move_uploaded_file($_FILES['document']['tmp_name'],$nom);
    }
    else
    {
      $error ="Erreur dans l'upload du document !";
      echo "Erreur dans l'upload du fichier";
      $app->flash('error', $error);
      $app->redirect('/labtic/ajouter-publication');
    }
  }

  // Adding the auteurs actifs and auteurs passifs
  $auteursPassifs = (isset($_POST['auteursPassifs'])) ? $_POST['auteursPassifs'] : [];
  $auteursActives = (isset($_POST['auteursActives'])) ? $_POST['auteursActives'] : [];

  foreach($auteursPassifs as $aut) {
    if($aut != "")
      continue;
    $q = 'INSERT INTO publication_auteurs_passifs values("'.$new_id.'", "'.$aut.'")';
    $db->exec($q);
  }

  foreach($auteursActives as $aut) {
    $autId = intval($aut);
    $q = 'INSERT INTO publication_auteurs_actifs values("'.$new_id.'", '.$autId.')';
    $db->exec($q);
  }

  $app->flash('success', 'Publication ajouté avec succès');
  $app->redirect('/labtic/ajouter-publication');
}

else {
  $app->flash('error', 'Erreur dans le formulaire');
  $app->redirect('/labtic/ajouter-publication');
  }

