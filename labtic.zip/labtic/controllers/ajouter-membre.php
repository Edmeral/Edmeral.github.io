<?php 
	session_start();
	require "inc/connexion.php";
	
	$db = connexion();

	$nom = $_POST['nom'];
	$prenom = $_POST['prenom'];
	$equipe_id = $_POST['equipe'];
	$specialite = $_POST['specialite'];
	$grade = $_POST['grade'];
	$adresse = $_POST['adresse'];
	$email = $_POST['email'];
	$telephone = $_POST['telephone'];
	$statut = $_POST['type-membre'];

	$login = $_POST['login'];
	$password = sha1($_POST['password']);

	$q = 'INSERT INTO membres(membre_id,nom,prenom,adresse,email,telephone,equipe_id,statut,specialite,grade) 
		  VALUES (null,:nom,:prenom,:adresse,:email,:telephone,:equipe_id,:statut,:specialite,:grade)';
	$req = $db->prepare($q);
	$req->execute(array('nom' => $nom,
						'prenom' => $prenom,
						'adresse' => $adresse,
						'email'=>$email,
						'telephone'=>$telephone,
						'equipe_id'=>$equipe_id,
						'statut'=>$statut,
						'specialite'=>$specialite,
						'grade'=>$grade));

	$new_id = (int) ($db->query('SELECT MAX(membre_id) n FROM membres')->fetch()['n']);

	if(isset($_FILES['photo']) && $_FILES['photo']['name']!="") 
	{	
		$extensions_valides = 'jpg' ;
		$extension_upload = strtolower(  substr(  strrchr($_FILES['photo']['name'], '.')  ,1) );
		if($extension_upload==$extensions_valides)
		{
			$nom="assets/images/membres/photo_{$new_id}.jpg";
			$resultat = move_uploaded_file($_FILES['photo']['tmp_name'],$nom);					 
		}
		else
		{
			$error ="Erreur dans l'upload de l'image !";
			$app->flash('error', $error);
			$app->redirect('/labtic/ajouter-membre');
		}	
	}

	if($statut == 'Permanent')
	{		

		$q = 'INSERT INTO utilisateurs(utilisateur_id,login,pass,membre_id,date_creation) 
		  		VALUES (null,:login,:pass,:id,CURRENT_DATE)';
		$req = $db->prepare($q);
		$req->execute(array('login' => $login,
							'pass' => $password,
							'id'=>$new_id));
	}

	$app->flash('success', "Membre créé avec succès !");
	$app->redirect('/labtic/membres');
