<?php
session_start();
require 'models/publications.php';
delete_publication($id);
$app->flash('success', "La publication a été supprimée.");
$app->redirect('/labtic/liste-publications');
?>