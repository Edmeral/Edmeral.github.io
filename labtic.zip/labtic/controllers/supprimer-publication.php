<?php
session_start();
if(!isset($_SESSION['privilege']) || ($_SESSION['membre'] != 'admin' && $_SESSION['membre'] != 'membre' )) exit(0);
require 'models/publications.php';
delete_publication($id);
$app->flash('success', "La publication a été supprimée.");
$app->redirect('/labtic/liste-publications');
?>