<?php
	require "models/utilisateur.php" ;
	session_start() ;
	$membre_id = $_SESSION['membre_id'];
	$old_pass = get_mdp_utilisateur($membre_id);

	$error = null;

	if (sha1($_POST['mdp']) != $old_pass) {
		$error = "L'ancien mot de passe est incorrect !";
	}
	else if ($_POST['nv_mdp_1'] != $_POST['nv_mdp_2'])
		$error = 'Les deux mots de passe ne sont pas indentique !';
	else {
		$db = connexion();
		$nv_mdp = sha1($_POST['nv_mdp_1']) ;
		$q = "UPDATE utilisateurs SET pass ='".$nv_mdp."'where membre_id=".$membre_id ;
		$req = $db ->query($q) ;
		if($req != true )
			$error = "Erreur dans la base de données";
	}

	if ($error != null)
		$app->render('mdp-admin.php', array('error' => $error));
	else
		$app->render('mdp-admin.php', array('success' => 'Le mot de passe a été modifié avec succés !'));