<?php
	session_start();
	require 'models/equipes.php';
	delete_equipe($id);
	$app->flash('success', "L'équipe a été supprimée.");
	$app->redirect('/labtic/equipes');
?>

