<?php
	session_start();

if(!isset($_SESSION['privilege']) || ($_SESSION['membre'] != 'admin') exit(0);
	require 'models/equipes.php';
	delete_equipe($id);
	$app->flash('success', "L'équipe a été supprimée.");
	$app->redirect('/labtic/equipes');
?>

