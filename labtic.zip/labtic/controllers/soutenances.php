<?php

	require 'models/soutenances.php';

	$soutenances = get_soutenances();
 
	$a = "" ;

	foreach ($soutenances as $soutenance)
	{
		$a .= "<tr>";
		$a .= "<td>"; 
		$a .= "<h4><a href='soutenance/".$soutenance['id_activite']."'>". utf8_encode($soutenance['titre']) ."</h4></a>";
		$a .= "<p> (Date: ".$soutenance['date_debut'];
		if(isset($soutenance['date_fin']))
		{
			$a.=" jusqu 'au : ".$soutenance['date_fin'];
		} 
		$a .=" ) </p>";
		$a .= "<p> Equipe :<a href='equipe/".$soutenance['equipe_id']."'>".utf8_encode($soutenance['libelle'])."</a> </p>";
		$a .= "</td>";
		$a .= "</tr>";
	}

	$affichage = $a ;
