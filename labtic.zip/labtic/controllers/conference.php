<?php

	require 'models/conferences.php';

	$contenu =  get_info_conference($id);

