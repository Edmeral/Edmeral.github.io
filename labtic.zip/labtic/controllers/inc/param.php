<?php
	// Workaround for getting mysql to work on my machine
	$mysql_pass = "";
	if (getenv('mysql_pass'))
		$mysql_pass = getenv('mysql_pass');
	//---
	define("HOST", "localhost");
	define("USER", "root");
	define("PASS", $mysql_pass);
	define("DB", "db_labtic");