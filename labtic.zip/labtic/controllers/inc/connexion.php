<?php
	function connexion()
	{
		require_once 'param.php';

		$dns  = 'mysql:host='.HOST.';dbname='.DB;
		$user = USER;
		$pass = PASS;

		try
		{
			$idcon = new PDO($dns, $user, $pass);
			return $idcon;
		}
		catch(PDOException $except)
		{
			echo 'Echec de la connexion : ' . $except->getMessage();
			exit();
			return FALSE;
		}
	}