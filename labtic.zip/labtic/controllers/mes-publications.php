<?php
	require "models/publications.php" ;
	$publications = get_publications_by_id_formatted($_SESSION['membre_id']);