<?php
	require 'models/membres.php';
	require 'models/equipes.php';
	$liste_membres = get_liste_membres();


	$s = '<table class="table m-0" >
			<thead>
				<tr>';

	$s .= (isset($_SESSION['privilege']) && $_SESSION['privilege'] == 'admin') ? '<th> </th>' : '';
	
	$s .='
				<th widht="80px"></th>
				<th>Nom</th>
				<th>Prénom</th>
				<th>Grade</th>
				<th>Spécialité</th>
				<th width="15%">Equipe</th>
				<th>Statut</th></tr>
			</thead>
			<tbody>';

	foreach($liste_membres as $membre)
	{
		$id = $membre['membre_id'];
		$equipe = get_nom_equipe($membre['equipe_id']);
		$s .= '<tr>';

		if(isset($_SESSION['privilege']) && $_SESSION['privilege'] == 'admin') 
		{
			$s .= '<td><a href="modifier-membre/'.$id.'" class="table-action-btn"><i class="md md-edit"></i></a>';
			$s .= '<br><a href="supprimer-membre/'.$id.'" class="table-action-btn"
					onclick="return confirm(\'Etes-vous sûrs de vouloir supprimer ce membre ?\')">
					<i class="md md-close"></i></a></td>';
		}
		$s .= '<td style="vertical-align: middle"><a href="membre/'.$id.'">';
		$s .= '<img class="img-thumbnail" width="40px" src="assets/images/membres/photo_'.$id.'.jpg" ></a></td>';
		$s .= '<td style="vertical-align: middle"><a href="membre/'.$id.'">'.utf8_encode($membre['nom']).'</a></td>';
		$s .= '<td style="vertical-align: middle"><a href="membre/'.$id.'">'.utf8_encode($membre['prenom']).'</a></td>';
		$s .= '<td style="vertical-align: middle">'.utf8_encode($membre['grade']).'</td>';
		$s .= '<td style="vertical-align: middle">'.($membre['specialite']).'</td>';
		if($membre['equipe_id'] != 0)
			$s .= '<td style="vertical-align: middle"><a href="equipe/'.$membre['equipe_id'].'">'.($equipe).'</td>';
		else
			$s .= '<td style="vertical-align: middle">-</td>';
		$s .= '<td style="vertical-align: middle">'.utf8_encode($membre['statut']).'</td>';
		$s .= '</a></tr>';
	}

	$s .= '	</tbody></table>';

	$table_membres = $s;
?>
