<?php

	require 'models/offres.php';

	$offre = get_offre($id);

?>	