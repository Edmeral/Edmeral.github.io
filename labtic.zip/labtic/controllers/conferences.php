<?php

	require 'models/conferences.php';

	$conferences = get_conference() ;

 
	$a = "" ;
	foreach ($conferences as $conference)
	{
		$a .= "<tr>";
		$a .= "<td>"; 
		$a .= "<h4><a href='conference/".$conference['id_activite']."'>". utf8_encode($conference['titre']) ."</h4></a>";
		$a .= "<p> (Date: ".$conference['date_debut'];
		if(isset($conference['date_fin']))
		{
			$a.=" jusqu 'au : ".$conference['date_fin'];
		} 
		$a .=" ) </p>";
		$a .= "<p> Equipe :<a href='equipe/".$conference['equipe_id']."'>".utf8_encode($conference['libelle'])."</a> </p>";
		$a .= "</td>";
		$a .= "</tr>";
	}

	$affichage = $a ;
