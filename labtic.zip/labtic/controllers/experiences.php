<?php
	require 'models/experiences.php';
	$experiences = get_liste_experiences($id);

	$s = '<div class="col-lg-2"></div>
		  <div class="col-lg-8">
				<div class="p-20">';
	$nb_exp = 0;
	foreach($experiences as $exp)
	{
		$nb_exp++;
		$s .= '
				<div class="timeline-2">
					<div class="time-item">
						<div class="item-info">
							<div class="text-muted">'. $exp['date_exp'] .' - '. utf8_encode($exp['date_fin_exp']) .'</div>
							<h3>'.$exp['experience'] .'</h3>
							<p><em>'. nl2br($exp['description']) .'</em></p>
						</div>
						<div class="row">
							<div class="col-lg-1">
							</div>
							<div class="col-lg-3">
								<a href="/labtic/modifier-experience/'. $exp['experience_id'] .'"><i class="fa fa-pencil"></i> Modifier</a>
							</div>
							<div <div class="col-lg-3">
								<a href="/labtic/supprimer-experience/'. $exp['experience_id'] .'" 
								onclick="return confirm(\'Etes-vous sûrs de vouloir supprimer cette expérience ?\')">
								<i class="fa fa-trash-o"></i> Supprimer</a>
							</div>
						</div>
						<p><br><br></p>
					</div>
				</div>
				';
	}

	$s .= '</div></div>';

	$table_experiences =  $s;
?>


		
