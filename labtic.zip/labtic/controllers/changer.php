<?php

	require "models/textes.php";
	$con = get_texte($id);
	$titre = get_titre($id);


	