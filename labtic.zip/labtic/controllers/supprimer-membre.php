<?php
	session_start();
	require 'models/membres.php';
	delete_membre($id);
	$app->flash('success', "Le membre a été supprimé.");
	$app->redirect('/labtic/membres');
?>

