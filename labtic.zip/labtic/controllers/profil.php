<?php
	session_start() ;
	require "inc/connexion.php";

	$membre_id=$_SESSION['membre_id'] ;

	if(isset($_FILES['photo']) && $_FILES['photo']['name']!="") 
	{	
		$extensions_valides = 'jpg' ;
		$extension_upload = strtolower(  substr(  strrchr($_FILES['photo']['name'], '.')  ,1) );
		if($extension_upload==$extensions_valides)
		{
			$nom="assets/images/membres/photo_{$membre_id}.jpg";
			$resultat = move_uploaded_file($_FILES['photo']['tmp_name'],$nom);					 
		}
		else
		{
			$error ="Erreur dans l'upload de l'image !";
			$app->flash('error', $error);
			$app->redirect('/labtic/profil');
		}	
	}

	// That's not how you check this, needs redoing
	if(isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['adresse']) && isset($_POST['telephone'])&& isset($_POST['email']))
	{
		$db =connexion();
		$nom = $_POST['nom'] ;
		$prenom = $_POST['prenom'] ;
		$adresse= $_POST['adresse'] ;
		$telephone = $_POST['telephone'];
		$email = $_POST['email'] ;
		$q = "UPDATE membres SET nom ='".$nom."',prenom ='".$prenom."',adresse ='".$adresse."',telephone ='".$telephone."',email ='".$email."'  WHERE membre_id =".$membre_id ;
	
		if(($db->query($q))==true)
		{
			$success = "Modifications enregistrées avec succées !";
			$app->flash('success', $success);
			$app->redirect('/labtic/profil');
		}  

	} 


?>