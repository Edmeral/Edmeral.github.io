<?php

	require 'models/soutenances.php';

	$contenu = get_info_soutenance($id);

?>	