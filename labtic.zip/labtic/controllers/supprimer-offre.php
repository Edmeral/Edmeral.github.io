<?php

	session_start();
	require 'models/postes.php';
	delete_offre($id);
	$app->flash('success', "L'activité a été supprimée.");
	$app->redirect('/labtic/offres');