<?php

	session_start();
if(!isset($_SESSION['privilege']) || ($_SESSION['membre'] != 'admin')) exit(0);
	require 'models/postes.php';
	delete_offre($id);
	$app->flash('success', "L'activité a été supprimée.");
	$app->redirect('/labtic/offres');