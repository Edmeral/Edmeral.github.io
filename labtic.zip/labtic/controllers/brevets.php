<?php

require "models/publications.php" ;

$publications = get_all_publications_formatted('brevet');




