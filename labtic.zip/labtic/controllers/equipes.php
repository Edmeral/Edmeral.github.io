<?php
	require 'models/equipes.php';
	$liste_equipes = get_liste_equipes();

	$s = '<table class="table m-0" >
			<thead>
				<tr>
					<th>Libellé	Equipe</th>
					<th>Description</th>
					<th>Thème</th>
					<th>Responsable</th>
					';
	if(isset($_SESSION['privilege']) && $_SESSION['privilege'] == 'admin')
		$s .= '<th>Options</th>';
	$s .= '</tr>
			</thead>
			<tbody>';

	foreach($liste_equipes as $equipe)
	{
		$id = $equipe['equipe_id'];
		$resp = get_responsable_equipe($equipe['id_responsable']);
		$s .= '<tr>';
		$s .= '<td style="vertical-align: middle"><a href="equipe/'.$id.'">'.($equipe['libelle']).'</a></td>';
		$s .= '<td style="vertical-align: middle">'.($equipe['description']).'</td>';
		$s .= '<td style="vertical-align: middle">'.($equipe['theme']).'</td>';
		$s .= '<td style="vertical-align: middle"><a href="membre/'.$resp['membre_id'].'" >'. $resp['prenom'] . ' ' . $resp['nom'] .'</a></td>';
		if(isset($_SESSION['privilege']) && $_SESSION['privilege'] == 'admin')
			$s .= '<td>&nbsp;&nbsp;
					<a href = "modifier-equipe/'.$equipe['equipe_id'].'" class="table-action-btn"><i class="md md-edit"></i></a>&nbsp;&nbsp;
					<a href = "supprimer-equipe/'.$equipe['equipe_id'].'" class="table-action-btn"><i class="md md-close"></i></a></td>';

		$s .= '</tr>';
	}

	$s .= '	</tbody></table>';

	$table_equipes = $s;
?>


		
