<?php
	require 'models/equipes.php';
	$nom_equipe = get_nom_equipe($id);
	$equipe = get_equipe($id);
	$table_membres_equipe = get_liste_membres_equipe($id);

	$s = '<table class="table m-0" >
			<thead>
				<tr>
					<th widht="80px"></th>
					<th>Nom</th>
					<th>Prénom</th>
					<th>Grade</th>
					<th>Spécialité</th>
					<th>Statut</th>
				</tr>
			</thead>
			<tbody>';

	foreach($table_membres_equipe as $membre)
	{
		$id = $membre['membre_id'];
		$s .= '<tr>';
		$s .= '<td style="vertical-align: middle"><a href="/labtic/membre/'.$id.'">';
		$s .= '<img class="img-thumbnail" width="40px" src="/labtic/assets/images/membres/photo_'.$id.'.jpg" ></a></td>';
		$s .= '<td style="vertical-align: middle"><a href="/labtic/membre/'.$id.'">'.utf8_encode($membre['nom']).'</a></td>';
		$s .= '<td style="vertical-align: middle"><a href="/labtic/membre/'.$id.'">'.utf8_encode($membre['prenom']).'</a></td>';
		$s .= '<td style="vertical-align: middle">'.utf8_encode($membre['grade']).'</td>';
		$s .= '<td style="vertical-align: middle">'.utf8_encode($membre['specialite']).'</td>';
		$s .= '<td style="vertical-align: middle">'.utf8_encode($membre['statut']).'</td>';
		$s .= '</a></tr>';
	}

	$s .= '	</tbody></table>';

	$table_membres = $s;
?>


		
