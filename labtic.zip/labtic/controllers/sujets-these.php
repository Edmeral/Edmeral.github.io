<?php
	require "models/postes.php";


	$postes = get_sujet_these() ;
		$a= "";
	foreach ($postes as $poste) {
		$a .= '<tr>';
		$a .= '<td> '. utf8_encode($poste['titre']) . '</td>';
		$a .= '<td>'.utf8_encode($poste['description']).'</td>' ;
		$a .= '<td>' . utf8_encode($poste['date_offre']) .'</td>';
		$a .= '<td>';
		if(file_exists("assets/offres/offre_".$poste['id_offre'].".pdf"))
			$a .='<a href="assets/offres/offre_'.$poste['id_offre'] .'.pdf"><i class="md md-file-download"></i></a>';

		$a .= '</td>';
		$a .= '</tr>' ;
	}

	$affichage = $a ;

