<?php
	require 'models/postes.php';
		
	$titre = $_POST['titre'] ;
	$type = $_POST['type'] ;
	$description = ($_POST['description']!="") ? $_POST['description']	: "Aucun" ;
	$date_offre = $_POST['date_offre'];
	$id = $_POST['id'];


	if(isset($_FILES['nom_fichier']) && $_FILES['nom_fichier']['name']!="")
  	{
    	$extensions_valides = 'pdf';
    	$extension_upload = strtolower(  substr(  strrchr($_FILES['nom_fichier']['name'], '.')  ,1) );
    	if($extension_upload==$extensions_valides)
    	{
      		$nom="assets/offres/offre_{$id}.pdf";
      		$resultat = move_uploaded_file($_FILES['nom_fichier']['tmp_name'],$nom);
    	}
    	else
    	{
      		$error ="Erreur dans l'upload du document !";
      		$app->flash('error', $error);
      		$app->redirect('/labtic/modifier-offre');
    	}
  	}

  	update_offre($titre,$type,$description,$date_offre,$id);
  	$success = "Modification effectué";
  	$app->flash('success',$success);
  	$app->redirect('/labtic/offres');


?>  	