<?php
	require "models/postes.php";


	$postes = get_offres() ;
		$a= "";
	foreach ($postes as $poste) {
		$a .= '<tr>';
		$a .= '<td> '. utf8_encode($poste['titre']) . '</td>';
		$a .= '<td>'.utf8_encode($poste['description']).'</td>';
		$a .= '<td>' . utf8_encode($poste['date_offre']) .'</td>';
		$a .= '<td><a href = "modifier-offre/'.$poste['id_offre'].'" class="table-action-btn"><i class="md md-edit"></i></a></td>';
		$a .= '<td><a href = "supprimer-offre/'.$poste['id_offre'].'" class="table-action-btn"><i class="md md-close"></i></a></td>';
		$a .= '</tr>' ;
	}

	$affichage = $a ;

