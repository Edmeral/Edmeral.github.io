<?php
	
	require 'models/activites.php';


	$titre = $_POST['titre'];
	$type = $_POST['type'];
	$equipe = $_POST['equipe'];
	$date_debut =$_POST['date_debut'];
	$date_fin =$_POST['date_fin'];
	$description= htmlspecialchars($_POST['description']);


	insert_activite($titre,$type,$equipe,$date_debut,$date_fin,$description);
	$app->flash('success', "Activité ajoutée avec succès !");
	$app->redirect('/labtic/ajouter-activite'); 



