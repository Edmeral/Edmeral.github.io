<?php
	require 'models/membres.php';
	require 'models/equipes.php';
	require 'models/publications.php';
	$membre = get_membre($id);
	$experiences = get_liste_experiences($id);
	$publications = get_publications_by_member_id($id);
	$owner = isset($membre['membre_id']) && isset($_SESSION['membre_id']) && $membre['membre_id'] == $_SESSION['membre_id'];
	$isAdmin = isset($_SESSION['privilege']) && $_SESSION['privilege'] == 'admin';
?>