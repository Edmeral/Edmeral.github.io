<?php

	require "models/textes.php" ;

	$mot = htmlspecialchars($_POST['contenu']);

	$id_contenu = $_POST['text'];

	update_text($mot,$id_contenu);

	$app->flash("success", " Contenu modifié avec succès !");
	$app->redirect('/labtic/changer/'.$id_contenu); 



