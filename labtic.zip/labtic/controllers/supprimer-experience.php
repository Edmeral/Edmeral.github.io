<?php
	session_start();
if(!isset($_SESSION['privilege']) || ($_SESSION['membre'] != 'admin' && $_SESSION['membre'] != 'membre' )) exit(0);
	require 'models/experiences.php';
	delete_experience($id);
	$app->flash('success', "L'expérience a été supprimée.");
	$app->redirect('/labtic/experiences/'.$_SESSION['membre_id']);
?>

