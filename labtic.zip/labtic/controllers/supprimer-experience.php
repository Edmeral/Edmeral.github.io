<?php
	session_start();
	require 'models/experiences.php';
	delete_experience($id);
	$app->flash('success', "L'expérience a été supprimée.");
	$app->redirect('/labtic/experiences/'.$_SESSION['membre_id']);
?>

