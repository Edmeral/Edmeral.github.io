<?php
	require 'models/membres.php';
	require 'models/equipes.php';
	$liste_doctorant = get_liste_doctorants();

	$s = '<table class="table m-0" style="vertical-align: middle">
			<thead>
				<tr>
					<th widht="80px"></th>
					<th>Nom</th>
					<th>Prénom</th>
					<th>Grade</th>
					<th>Spécialité</th>
					<th width="15%">Equipe</th>
					<th>Statut</th>
				</tr>
			</thead>
			<tbody>';

	foreach($liste_doctorant as $membre)
	{
		$id = $membre['membre_id'];
		$equipe = get_nom_equipe($membre['equipe_id']);
		$s .= '<tr>';
		$s .= '<td style="vertical-align: middle"><a href="membre/'.$id.'">';
		$s .= '<img class="img-circle thumb-sm" src="assets/images/membres/photo_'.$id.'.jpg" ></a></td>';
		$s .= '<td style="vertical-align: middle"><a href="membre/'.$id.'">'.utf8_encode($membre['nom']).'</a></td>';
		$s .= '<td style="vertical-align: middle"><a href="membre/'.$id.'">'.utf8_encode($membre['prenom']).'</a></td>';
		$s .= '<td style="vertical-align: middle">'.utf8_encode($membre['grade']).'</td>';
		$s .= '<td style="vertical-align: middle">'.utf8_encode($membre['specialite']).'</td>';
		if($membre['equipe_id'] != 0)
			$s .= '<td style="vertical-align: middle"><a href="equipe/'.$membre['equipe_id'].'">'.$equipe.'</td>';
		else
			$s .= '<td style="vertical-align: middle">-</td>';
		$s .= '<td style="vertical-align: middle">'.utf8_encode($membre['statut']).'</td>';
		$s .= '</a></tr>';
	}

	$s .= '	</tbody></table>';

	$table_doctorants = $s;
?>