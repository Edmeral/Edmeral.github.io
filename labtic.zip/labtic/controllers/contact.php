<?php

	$to = 'anaschafik123@gmail.com';
	$message = 'Nom : '.$_POST['nom'].' .\n';
	$message .= 'E-mail : '.$_POST['email'].' .\n';
	$message .= 'Nom : '.$_POST['message'].' .\n';


	//mail($to,'sujet1', $message);

	$app->flash('success', "Message envoyé.");
	$app->redirect('/labtic/contact');



	
