<?php
	require 'models/accueil.php';

	//the carousel stuff
	$liste_actualites = get_liste_actualites();
	$liste_offres = get_liste_offres();
	$liste_publications = get_liste_publications();

	$mot_directeur = '<div class="row">
		<div class="col-sm-12">
		<img src="/labtic/assets/images/logo.png" class="img-responsive" style="float:left;"/>
		'.get_mot_directeur().'<br><br><br>
		</div></div>';
		

	$s = '<table class="table"><thead>';
	$s .=  '<thead>
				<tr>
					<th>Thème</th>
					<th width="100px">Date</th>
				</tr>
			</thead>
			<tbody>';

	foreach($liste_actualites as $actualite)
	{
		$s .= '<tr>';
		$s .= '<td><span style="color:#1e8f75">' . utf8_encode($actualite['type']) . '</span> : ';
		$s .= '<a href="actualite/'.$actualite['id_activite'].'">' . utf8_encode($actualite['titre']) . '</a></td>';
		if($actualite['date_debut'] == $actualite['date_fin'])
			$s .= '<td>' . $actualite['date_debut'] . '</td>';
		else
			$s .= '<td>' . $actualite['date_debut'] . '<br> à ' . $actualite['date_fin'] . '</td>';
		$s .= '</tr>';
	}

	$s .= '</tbody></table>';
	$actualites = $s;

		
	$s = '<table class="table"><thead>';
	$s .=  '<thead>
				<tr>
					<th>Titre (date)</th>
				</tr>
			</thead>
			<tbody>';

	foreach($liste_publications as $pub)
	{
		$s .= '<tr>';
		$s .= '<td><span style="color:#ae5050">' . utf8_encode($pub['type']) . '</span> : ';
		$s .= '<a href="publication/'.$pub['id'].'">' . utf8_encode($pub['titre']) . '</a>';
		$s .= ' &nbsp;('.$pub['annee_publication'].')</td>';
	}

	$s .= '</tbody></table>';
	$publications = $s;


	$a = '<table class="table"><thead>';
	$a .=  '<thead>
				<tr>
					<th>Poste</th>
				</tr>
			</thead>
			<tbody>';

	foreach($liste_offres as $offre)
	{
		$a .= '<tr>';
		$a .= '<td><a href="offre/'.$offre['id_offre'].'"> '. utf8_encode($offre['titre']) . '</a></td>';
		$a .= '</tr>' ;
	}

	$a .= '</tbody></table>';
	$offres = $a;
?>