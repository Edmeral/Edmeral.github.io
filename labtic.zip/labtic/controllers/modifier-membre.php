<?php
	session_start();
	require "inc/connexion.php";

	$membre_id = $id;

	if(isset($_FILES['photo']) && $_FILES['photo']['name']!="") 
	{	
		$extensions_valides = 'jpg';
		$extension_upload = strtolower(  substr(  strrchr($_FILES['photo']['name'], '.')  ,1) );
		if($extension_upload==$extensions_valides)
		{
			$nom="assets/images/membres/photo_{$membre_id}.jpg";
			$resultat = move_uploaded_file($_FILES['photo']['tmp_name'],$nom);
			if(!$resultat)
			{
				$error ="Erreur pendant l'upload de la photo (image trop grande)";
				$app->flash('error', $error);
				$app->redirect('/labtic/modifier-membre/'.$membre_id);
			}
		}
	}

	// That's not how you check this, needs redoing
	if(isset($_POST['nom']))
	{
		$db =connexion();
		$nom = $_POST['nom'] ;
		$prenom = $_POST['prenom'] ;
		$adresse= $_POST['adresse'] ;
		$telephone = $_POST['telephone'];
		$email = $_POST['email'];
		$id_equipe = $_POST['equipe'];
		$specialite = $_POST['specialite'];
		$grade = $_POST['grade'];

		$q = "UPDATE membres SET nom ='".$nom."',prenom ='".$prenom."',adresse ='".$adresse."',telephone ='".$telephone."'";
		$q .= ",email ='".$email."', equipe_id = ".$id_equipe.", specialite = '".$specialite."', grade = '".$grade."' WHERE membre_id =".$membre_id;
	
		if(($db->query($q)))
		{
			$success = "Modifications enregistrées avec succées !";
			$app->flash('success', $success);
			$app->redirect('/labtic/membres');
		}  
		else
		{
			$error ="Erreur mysrtérieuse.";
			$app->flash('error', $error);
			$app->redirect('/labtic/modifier-membre/'.$membre_id);
		}
	}
	else
	{
			$error ="Une erreur s'est produite. Veuillez réessayer.";
			$app->flash('error', $error);
			$app->redirect('/labtic/modifier-membre/'.$membre_id);
	}
?>