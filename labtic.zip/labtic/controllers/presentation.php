<?php
	require 'models/textes.php';
	$presentation_labtic = '<p>'.get_presentation_labtic().'</p>';
	$thematique = '<p>'.get_thematique().'</p>';
	$mots_cles = '<p>'.get_mots_cles().'</p>';
	$axes_recherche = '<p>'.get_axes_recherche().'</p>';
?>

