<?php
	
	require "models/publications.php";
	$publication = get_publication($id);
	$pdf_exists = file_exists("assets/publications/publication_".$publication['id'].".pdf");


