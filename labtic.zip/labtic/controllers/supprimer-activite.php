<?php
	session_start();
	if(!isset($_SESSION['privilege']) || ($_SESSION['membre'] != 'admin' )) exit(0);
	require 'models/activites.php';
	delete_activite($id);
	$app->flash('success', "L'activité a été supprimée.");
	$app->redirect('/labtic/activites');
?>