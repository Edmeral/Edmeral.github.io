<?php
	session_start();
	require 'models/activites.php';
	delete_activite($id);
	$app->flash('success', "L'activité a été supprimée.");
	$app->redirect('/labtic/activites');
?>