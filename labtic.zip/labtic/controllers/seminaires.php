<?php
	


	require 'models/seminaires.php';

	$seminaires = get_seminaires() ;
 
	$a = "" ;
	foreach ($seminaires as $seminaire)
	{
		$a .= "<tr>";
		$a .= "<td>"; 
		$a .= "<h4><a href='seminaire/".$seminaire['id_activite']."'>". utf8_encode($seminaire['titre']) ."</h4></a>";
		$a .= "<p> (Date: ".$seminaire['date_debut'];
		if(isset($seminaire['date_fin']))
		{
			$a.=" jusqu 'au : ".$seminaire['date_fin'];
		} 
		$a .=" ) </p>";
		$a .= "<p> Equipe :<a href='equipe/".$seminaire['equipe_id']."'>".utf8_encode($seminaire['libelle'])."</a> </p>";
		$a .= "</td>";
		$a .= "</tr>";
	}

	$affichage = $a ;
