<?php
	require "inc/header.php";
	require "controllers/equipe.php";
	require "models/membres.php";
	
	$resp = get_membre($equipe['id_responsable']);
?>

<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
					<h1>&nbsp;&nbsp;&nbsp;<?= $equipe['libelle'] ?></h1>
			<div class="row">
				<div class="col-lg-2">
				</div>
				<div class="col-lg-8">
					<div>
					</div>
					<div class="panel panel-border panel-custom">
						<div class="panel-heading">
							<h3 class="panel-title">Fiche de présentation</h3>
						</div>
						<div class="panel-body">
							<table class="table">
								<tr><th>Description : </th><td><?= $equipe['description'] ?></td>
									<td rowspan="3">
									<img src="../assets/images/equipes/photo_logo_<?=$equipe['equipe_id'] ?>.jpg" class="img-responsive"/>
									</td></tr>
								<tr><th>Thème : </th><td><?= $equipe['theme'] ?></td></tr>
								<tr><th>Responsable : </th>
									<td><a href="../membre/<?= $resp['membre_id'] ?>"><?= $resp['nom'] . ' ' . $resp['prenom'] ?></a></td></tr>
							</table>
						</div>
					</div>
					<h4 class="m-t-0 header-title"><b>Membres de l'équipe <?= $nom_equipe ?></b></h4>
					<div class="p-20">
						<div class="table-responsive">
							<?= $table_membres ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>