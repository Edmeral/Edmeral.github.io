					</div>
				</div>
			</div>
			<footer class="footer text-right">
				Copyright © 2016 LabTIC. All Rights Reserved.
			</footer>
		</div>

		<script>
			var resizefunc = [];
		</script>

		<!-- jQuery  -->
		<script src="/labtic/assets/js/jquery.min.js"></script>
		<script src="/labtic/assets/js/bootstrap.min.js"></script>
		<script src="/labtic/assets/js/detect.js"></script>
		<script src="/labtic/assets/js/fastclick.js"></script>
		<script src="/labtic/assets/js/jquery.slimscroll.js"></script>
		<script src="/labtic/assets/js/jquery.blockUI.js"></script>
		<script src="/labtic/assets/js/waves.js"></script>
		<script src="/labtic/assets/js/wow.min.js"></script>
		<script src="/labtic/assets/js/jquery.nicescroll.js"></script>
		<script src="/labtic/assets/js/jquery.scrollTo.min.js"></script>

		<script src="/labtic/assets/plugins/peity/jquery.peity.min.js"></script>
		
        <script src="/labtic/assets/plugins/moment/moment.js"></script>
        <script src='/labtic/assets/plugins/fullcalendar/dist/fullcalendar.min.js'></script>
        <script src="/labtic/assets/pages/jquery.fullcalendar.js"></script>

		<!-- jQuery  -->
		<script src="/labtic/assets/plugins/waypoints/lib/jquery.waypoints.js"></script>
		<script src="/labtic/assets/plugins/counterup/jquery.counterup.min.js"></script>

		<script src="/labtic/assets/plugins/morris/morris.min.js"></script>
		<script src="/labtic/assets/plugins/raphael/raphael-min.js"></script>

		<script src="/labtic/assets/plugins/jquery-knob/jquery.knob.js"></script>

		<script src="/labtic/assets/pages/jquery.dashboard.js"></script>

		<script src="/labtic/assets/js/jquery.core.js"></script>
		<script src="/labtic/assets/js/jquery.app.js"></script>

        <script src="/labtic/assets/plugins/moment/moment.js"></script>
     	<script src="/labtic/assets/plugins/timepicker/bootstrap-timepicker.min.js"></script>
     	<script src="/labtic/assets/plugins/mjolnic-bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
     	<script src="/labtic/assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
     	<script src="/labtic/assets/plugins/clockpicker/dist/jquery-clockpicker.min.js"></script>
     	<script src="/labtic/assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>

        <script src="/labtic/assets/plugins/owl.carousel/dist/owl.carousel.min.js"></script>
        
        <script type="text/javascript">
            jQuery(document).ready(function($) {
            	// Ajouter membre : toggle the login-pass fields visibilty
    			$(function() {
				    $('#type-membre').change(function(){
				        if($('#type-membre').val() == 'Permanent') {
				            $('#infos-login').show(); 
				        } else {
				            $('#infos-login').hide(); 
				        } 
				    });
				});

                //owl carousel
                $("#owl-slider").owlCarousel({
                    loop:true,
				    nav:false,
				    autoplay:true,
				    autoplayTimeout:4000,
				    autoplayHoverPause:true,
					animateOut: 'fadeOut',
				    responsive:{
				        0:{
				            items:1
				        },
				        600:{
				            items:1
				        },
				        1000:{
				            items:1
				        }
				    }
                });
                
                $("#owl-slider-2").owlCarousel({
                    loop:false,
				    nav:false,
				    autoplay:true,
				    autoplayTimeout:4000,
				    autoplayHoverPause:true,
				    responsive:{
				        0:{
				            items:1
				        },
				        600:{
				            items:1
				        },
				        1000:{
				            items:1
				        }
				    }
                });
                
                //Owl-Multi
                $('#owl-multi').owlCarousel({
				    loop:true,
				    margin:20,
				    nav:false,
				    autoplay:true,
				    responsive:{
				        0:{
				            items:1
				        },
				        480:{
				            items:2
				        },
				        700:{
				            items:4
				        },
				        1000:{
				            items:3
				        },
				        1100:{
				            items:5
				        }
				    }
				})
            });
            
        </script>
        

		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$('.counter').counterUp({
					delay: 100,
					time: 1200
				});

				$(".knob").knob();

			});
		</script>
		<script type="text/javascript">
			jQuery(document).ready(function() {

				// Time Picker
				jQuery('#timepicker').timepicker({
					defaultTIme : false
				});
				jQuery('#timepicker2').timepicker({
					showMeridian : false
				});
				jQuery('#timepicker3').timepicker({
					minuteStep : 15
				});
				
				//colorpicker start

                $('.colorpicker-default').colorpicker({
                    format: 'hex'
                });
                $('.colorpicker-rgba').colorpicker();
                
                // Date Picker
                $('.datepicker').datepicker({dateFormat: 'yyyy-mm-dd'} );

                //Clock Picker
                $('.clockpicker').clockpicker({
                	donetext: 'Done'
                });
                
                $('#single-input').clockpicker({
				    placement: 'bottom',
				    align: 'left',
				    autoclose: true,
				    'default': 'now'
				});
				$('#check-minutes').click(function(e){
				    // Have to stop propagation here
				    e.stopPropagation();
				    $("#single-input").clockpicker('show')
				            .clockpicker('toggleView', 'minutes');
				});
				
				
				//Date range picker
				$('.input-daterange-datepicker').daterangepicker({
					buttonClasses: ['btn', 'btn-sm'],
		            applyClass: 'btn-default',
		            cancelClass: 'btn-white'
				});
		        $('.input-daterange-timepicker').daterangepicker({
		            timePicker: true,
		            format: 'MM/DD/YYYY h:mm A',
		            timePickerIncrement: 30,
		            timePicker12Hour: true,
		            timePickerSeconds: false,
		            buttonClasses: ['btn', 'btn-sm'],
		            applyClass: 'btn-default',
		            cancelClass: 'btn-white'
		        });
		        $('.input-limit-datepicker').daterangepicker({
		            format: 'MM/DD/YYYY',
		            minDate: '06/01/2015',
		            maxDate: '06/30/2015',
		            buttonClasses: ['btn', 'btn-sm'],
		            applyClass: 'btn-default',
		            cancelClass: 'btn-white',
		            dateLimit: {
		                days: 6
		            }
		        });
		
		        $('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
		
		        $('#reportrange').daterangepicker({
		            format: 'MM/DD/YYYY',
		            startDate: moment().subtract(29, 'days'),
		            endDate: moment(),
		            minDate: '01/01/2012',
		            maxDate: '12/31/2015',
		            dateLimit: {
		                days: 60
		            },
		            showDropdowns: true,
		            showWeekNumbers: true,
		            timePicker: false,
		            timePickerIncrement: 1,
		            timePicker12Hour: true,
		            ranges: {
		                'Today': [moment(), moment()],
		                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
		                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
		                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
		                'This Month': [moment().startOf('month'), moment().endOf('month')],
		                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
		            },
		            opens: 'left',
		            drops: 'down',
		            buttonClasses: ['btn', 'btn-sm'],
		            applyClass: 'btn-default',
		            cancelClass: 'btn-white',
		            separator: ' to ',
		            locale: {
		                applyLabel: 'Submit',
		                cancelLabel: 'Cancel',
		                fromLabel: 'From',
		                toLabel: 'To',
		                customRangeLabel: 'Custom',
		                daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
		                monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
		                firstDay: 1
		            }
		        }, function (start, end, label) {
		            console.log(start.toISOString(), end.toISOString(), label);
		            $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
		        });
				
			});
		</script>
		<script src="/labtic/assets/plugins/footable/js/footable.all.min.js"></script>
		
		<script src="/labtic/assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js" type="text/javascript"></script>

		<!--FooTable Example-->
		<script src="/labtic/assets/pages/jquery.footable.js"></script>

        <script src="/labtic/assets/plugins/tinymce/tinymce.min.js"></script>
        
        <script type="text/javascript">
        	$(document).ready(function () {
			    if($("#elm1").length > 0){
			        tinymce.init({
			            selector: "textarea#elm1",
			            theme: "modern",
			            height:300,
			            plugins: [
			                "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
			                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
			                "save table contextmenu directionality emoticons template paste textcolor"
			            ],
			            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | l      ink image | print preview media fullpage | forecolor backcolor emoticons", 
			            style_formats: [
			                {title: 'Bold text', inline: 'b'},
			                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
			                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
			                {title: 'Example 1', inline: 'span', classes: 'example1'},
			                {title: 'Example 2', inline: 'span', classes: 'example2'},
			                {title: 'Table styles'},
			                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
			            ]
			        });    
			    }  
			});
        </script>

	</body>
</html>