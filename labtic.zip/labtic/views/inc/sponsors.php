<div class="row">
	<div class="col-lg-12">
	<div class="panel panel-border panel-custom">
		<div class="panel-heading">
			<h3 class="panel-title">
				<i class="ion-ios7-calendar-outline"></i>
				&nbsp;&nbsp; Nos sponsors
			</h3>
		</div>
		<div class="row">
			<div class="panel-body inner-padding">
				<div class="col-lg-2">
				</div>
					<table class="col-lg-8">
						<tr>
							<td>
								<a href="#"><img src="/labtic/assets/images/sponsors/cnrst.jpg" width="70" height="70"></a>
								<br><br>
							</td>
							<td>
								<a href="#"><img src="/labtic/assets/images/sponsors/DSOC.png" width="70" height="70"></a>
								<br><br>
							</td>
							<td>
								<a href="#"><img src="/labtic/assets/images/sponsors/ens.jpg" width="70" height="70"></a>
								<br><br>
							</td>
							<td>
								<a href="#"><img src="/labtic/assets/images/sponsors/ensat.jpg" width="70" height="70"></a>
								<br><br>
							</td>
							<td>
								<a href="#"><img src="/labtic/assets/images/sponsors/liris.jpg" width="70" height="70"></a>
								<br><br>
							</td>
							<td>
							</td>
						</tr>
						<tr>
							<td colspan="5"><br></td>
						</tr>
					</table>
					<br><br>
					<br><br>
			</div>
		</div>
	</div>
	</div>
</div>