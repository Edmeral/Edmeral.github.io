<?php
	// Commencer la session dans toutes les pages du site
	if(!isset($_SESSION)) // don't start a session if it's already started
		session_start();
	$connecte = isset($_SESSION['created']);
	$mid = $connecte ? $_SESSION['membre_id'] : 0;

	// Définition des informations utilisées dans l'entête de toutes les pages du site
	$titre = "LabTIC - Laboratoire de Traitement d'Information et Communication";

	$liens = array();
	$icone = array();
	$icone['par_defaut'] = 'ion-arrow-right-a';

	$liens['Présentation'] 	= [ 'LabTIC' 		=> './presentation', 
								'Organigramme'	=> './organigramme', 
								'Plaquettes'	=> './plaquettes',
								'Membres'		=> ['Membres du LabTIC' 	=> './membres',
													'Doctorants du Labtic'	=> './doctorants' ] ];

	$liens['Structure'] 	= [ 'Equipes' 		=> './equipes',  
								'Partenaires'	=> './partenaires' ];

	$liens['Publications'] 	= [ 'Publications' 	=> './publications', 
								'Thèses'		=> './theses', 
								'HDR'			=> './hdr',
								'Brevets'		=> './brevets',
								'Autres'		=> './autres' ];

	$liens['Activités'] 	= [ 'Conférences'		=> './conferences', 
								'Soutenances'		=> './soutenances',
								'Séminaires'		=> './seminaires'];

	$liens['Offres'] 		= [ 'Postes'	=> ['Postes Enseignat-Chercheur' 	=> './postes-enseignant',
												'Postes Ingénieur'				=> './postes-ingenieur' ],
								'Sujets'	=> ['Sujets Thèse' 	=> './sujets-these',
												'Sujets Stage'	=> './sujets-stage' ]];

	$liens['Contact'] 	= [ 'Contact' 		=> './contact' ];

	$liens['A propos'] 	= [ 'A propos' 		=> './a-propos' ];


	$icone['Présentation'] 	= 'ion-star';
	$icone['Structure'] 	= 'ion-map';
	$icone['Contact']  		= 'ion-arrow-right-a';
	$icone['Activités']		= 'ion-flag';
	$icone['Offres'] 		= 'ion-university';
	$icone['Contact']		= 'md md-mail';
	$icone['A propos'] 		= 'ion-flask';
	
	$icone_membre = array();
	$icone_membre['par_defaut'] = 'ion-arrow-right-a';

	$liens_membre['Profil'] 	= [ 'Voir mon profil' => './membre/'.$mid, 
									'Modifier mon profil' 	  =>'./profil',
									'Changer le mot de passe' =>'./changer-mdp'];

	$liens_membre['Expériences'] = [ 'Mes Expériences' => './experiences/'.$mid,
									 'Ajouter une expérience' => './ajouter-experience'];

	$liens_membre['Publications'] = [ 'Mes publications' => './mes-publications/'.$mid,
									  'Ajouter une publication' => './ajouter-publication'];

	$icone_membre['Profil'] 		= 'md md-account-circle';
	$icone_membre['Expériences'] 	= 'ion-checkmark-round';
	$icone_membre['Mon équipe'] 	= 'md-people';
	$icone_membre['Publications'] 	= 'md-view-list';

	$liens_admin = array() ; 

	$liens_admin['Membres']		= ['Ajouter un membre' =>'./ajouter-membre',
								   'Voir les membres'=>'./membres'];

	$liens_admin['Equipes']		= ['Ajouter une équipe' =>'./ajouter-equipe',
								   'Voir les équipes'=>'./equipes'];

	$liens_admin['Offres']		= ['Ajouter une offre' =>'./ajouter-offre',
								   'Voir les offres'=>'./offres'];

	$liens_admin['Publications'] = ['Ajouter une publication' =>'./ajouter-publication',
									'Voir les publications'=>'./liste-publications'];

	$liens_admin['Activités'] 	= ['Ajouter une activité' =>'./ajouter-activite',
								   'Voir les activités'=>'./activites'];

	$liens_admin['Paramètres'] 	= ['Changer le mot du directeur'=>'./changer/mot-directeur',
								   'Changer la thématique'=>'./changer/thematique',
								   'Changer la présentation'=>'./changer/presentation',
								   'Changer les axes de recherche'=>'./changer/axes-recherche',];



	$icone_admin = array() ; 
	$icone_admin['par_defaut'] = 'ion-arrow-right-a';
	$icone_admin['Membres'] = 'md-account-circle';
	$icone_admin['Offres'] = 'md-assignment-ind';
	$icone_admin['Publications'] = 'md-view-list';
	$icone_admin['Activités'] = 'md-event';
	$icone_admin['Equipes'] = 'md-account-child';
	$icone_admin['Paramètres'] = 'md-my-library-books';


	function construire_menu($liens, $icone)
	{		$premier_actif = true;
		foreach($liens as $categorie => $contenu)
		{
			$ico = isset($icone[$categorie]) ? $icone[$categorie] : $icone['par_defaut'];
			if(count($contenu) == 1)
			{
				echo '<li>';
				echo '<a href="/labtic/'.$contenu[$categorie].'" class="waves-effect"><i class="'.$ico.'"></i><span>'.$categorie.'</span></a>';
				echo '</li>';
			}
			else
			{
				echo '<li class="has_sub">';
				echo '<a href="javascript:void(0);" class="waves-effect"><i class="'.$ico.'"></i><span>'.$categorie.'</span></a>';
				echo '<ul>';
				
				foreach($contenu as $section => $contenu2)
				{
					if(count($contenu2) == 1)
					{
						echo '<li>';
						echo '<a href="/labtic/'.$contenu2.'" class="waves-effect"><span>'.$section.'</span></a>';
						echo '</li>';
					}
					else
					{
						echo '<li class="has_sub">';
						echo '<a href="javascript:void(0);" class="waves-effect"><span>'.$section.'</span> </a>';
						echo '<ul>';
						
						foreach($contenu2 as $sous_section => $lien)
						{
							echo '<li><a href="/labtic/'.$lien.'"><span>'.$sous_section.'</span></a></li>';
						}
						echo '</ul>';
						echo '</li>';
					}
				}
				echo '</ul>';
			}
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="LabTIC - Laboratoire de Traitement d'Information et Communication">
	<meta name="author" content="Belhachmi Aissam, Chafik Anasse, Harrando Ismail">

	<link rel="shortcut icon" href="assets/images/favicon.png">

	<title><?= $titre ?></title>

    <link href="/labtic/assets/plugins/fullcalendar/dist/fullcalendar.css" rel="stylesheet" />
    <link href="/labtic/assets/plugins/select2/select2.css" rel="stylesheet" type="text/css" />

	<link href="/labtic/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="/labtic/assets/css/core.css" rel="stylesheet" type="text/css" />
	<link href="/labtic/assets/css/components.css" rel="stylesheet" type="text/css" />
	<link href="/labtic/assets/css/icons.css" rel="stylesheet" type="text/css" />
	<link href="/labtic/assets/css/pages.css" rel="stylesheet" type="text/css" />
	<link href="/labtic/assets/css/responsive.css" rel="stylesheet" type="text/css" />
	<link href="/labtic/assets/css/labtic.css" rel="stylesheet" type="text/css" />


	<!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->

	<script src="/labtic/assets/js/modernizr.min.js"></script>
	</head>
	<body class="fixed-left">

		<!-- Begin page -->
		<div id="wrapper">

			<!-- Top Bar Start -->
			<div class="topbar">

				<!-- LOGO -->
				<div class="topbar-left">
					<div class="text-center">
						<a href="/labtic/" class="logo">
							<i class="ion-flask"> </i>&nbsp;
							<span>Lab<span style="color: #5ebeaa">Tic</span></span>
						</a>
					</div>
				</div>


				<!-- Button mobile view to collapse sidebar menu -->
				<div class="navbar navbar-default" role="navigation">
					<div class="container">
						<div class="">
							<!-- Icone de minimsation du menu -->
							<div class="pull-left">
								<button class="button-menu-mobile open-left">
									<i class="ion-navicon"></i>
								</button>
								<span class="clearfix"></span>
							</div>

							<!-- Barre de recherche -->
							<!--form role="search" class="navbar-left app-search pull-left hidden-xs">
								<input type="text" placeholder="Rechercher..." class="form-control">
								<a href=""><i class="fa fa-search"></i></a>
							</form-->

							<!-- Partie droite de l'entête -->
							<ul class="nav navbar-nav navbar-right pull-right">
								<li class="dropdown hidden-xs">
									<li class="hidden-xs">
										<a href="#" id="btn-fullscreen" class="waves-effect waves-light"><i class="icon-size-fullscreen"></i></a>
									</li>
									<?php
									if($connecte && $_SESSION['privilege'] == 'membre')
										echo '
											<li class="dropdown">
												<a href="" class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true">
												<img src="/labtic/assets/images/membres/photo_'.$mid.'.jpg" alt="user-img" class="img-circle"> </a>
												<ul class="dropdown-menu">
													<li><a href="/labtic/membre/'.$mid.'"><i class="ti-user m-r-5"></i> Profil</a></li>
													<li><a href="/labtic/profil"><i class="ti-settings m-r-5"></i> Paramètres</a></li>
													<li><a href="/labtic/deconnexion"><i class="ti-power-off m-r-5"></i> Déconnexion</a></li>
												</ul>
											</li>';
									?>
									<li>
										<?php
										if(isset($_SESSION['created']))
											echo '<a href="/labtic/deconnexion" class="waves-effect waves-light">Déconnexion&nbsp; <sub class="ion-log-out" style="font-size: 30px;"></sub></a>';
										else
											echo '<a href="/labtic/connexion" class="waves-effect waves-light">Connexion&nbsp; <sub class="ion-log-in" style="font-size: 30px;"></sub></a>';
										?>
									</li>
								</ul>

							</div>
							<!--/.nav-collapse -->
						</div>
					</div>
			</div>
			<!-- Top Bar End -->


			<div class="left side-menu">
				<div class="sidebar-inner slimscrollleft">
					<div id="sidebar-menu">
						<?php
							if($connecte && $_SESSION['privilege'] == 'membre')
							{
								?>			
								<ul>
									<li class="text-muted menu-title">Gestion de compte</li>
									<?php construire_menu($liens_membre,$icone_membre); ?>
								</ul>
							<?php 
							}
							if(isset($_SESSION['privilege']) && $_SESSION['privilege'] == 'admin')
							{
						 	?>
						 	<ul>
						 		<li class="text-muted menu-title">Admininstration</li>
								<?php construire_menu($liens_admin,$icone_admin); ?>
						 	</ul>
							<?php
							}
						?>
						<ul>
							<li class="text-muted menu-title">Navigation</li>
							<?php construire_menu($liens,$icone); ?>
						</ul>
					</div>
				</div>
			</div>

			<!-- ============================================================== -->
			<!-- Start right Content here -->
			<!-- ============================================================== -->
			<div class="content-page">
				<!-- Start content -->
				<div class="content">
					<div class="container">
