<?php
	require "inc/header.php";
	require "controllers/soutenance.php";
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1><?= utf8_encode($contenu['titre']) ?></h1><br>
					<div class="text-muted"><h5>(Date prévu: <?= utf8_encode($contenu['date_debut']) ?>)</h5></div><br>
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-10">
							<div class="text-muted" ><h4><strong><i class="md md-send"></i>&nbsp;Résumé :</strong></h4></div><br>
						</div>			
					</div>
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-10">
							<?php $description ='<p>'.utf8_encode($contenu['description']).'</p>';
									echo html_entity_decode($description); ?><br>
						</div>
					</div>
					
				</br>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>