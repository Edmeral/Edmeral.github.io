<?php
	require "inc/header.php";
	require "controllers/soutenance.php";
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
			<div class="row">
			<div class="col-sm-2"></div>
			<div class="col-sm-8">
				<p>
					<h1><?= utf8_encode($contenu['titre']) ?></h1><br>
					<div class="text-muted">
					<h4><b>Date : </b> 
						<?= ($contenu['date_debut'] == $contenu['date_debut']) ? $contenu['date_debut'] : ($contenu['date_debut'] . " - " .$contenu['date_debut']) ?>
					</h4></div>
					<div class="text-muted">
					<h4><b>Equipe organisatrice : </b> 
						<a href="../equipe/<?= $contenu['equipe_id'] ?>"><?= get_nom_equipe($contenu['equipe_id']) ?></a>
					</h4></div><br>
					<div class="text-muted" ><h4><strong>&nbsp;Résumé :</strong></h4>
							<?php $description ='<p>'.utf8_encode(nl2br($contenu['description'])).'</p>';
									echo html_entity_decode($description); ?><br>
					</div>
				<div>
				</div>
				</br>
				</p>
			</div>
		</div>
	</div>
</div>
