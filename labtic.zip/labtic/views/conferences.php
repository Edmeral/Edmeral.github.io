<?php
	require "inc/header.php";
	require 'controllers/conferences.php';
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Conférences</h1>
					<br>
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-10">
							<table id="demo-foo-filtering" class="table table-striped toggle-circle m-b-0" data-page-size="2">
								<tbody>
								<?= $affichage ?>									
								</tbody>
								<tfoot>
											<tr>
												<td>
													<div class="text-right">
														<ul class="pagination pagination-split m-t-30 m-b-0"></ul>
													</div>
												</td>
											</tr>
								</tfoot>
							</table>
						</div>
					</div>

				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>