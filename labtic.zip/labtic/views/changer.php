<?php
	require "inc/header.php";
	require "controllers/changer.php";
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<?php 
				if (isset($_SESSION['slim.flash']['success']))
					echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
				?>
				<p>
					<h1><?= $titre ?><br><br></h1>

					<div class="col-md-1"></div>
					<div class="col-md-10">
						<form class="form-horizontal" role="form" method="POST" action="/labtic/changer-text">
						<div class="form-group">
							<div class="col-md-10">
								<textarea class="form-control" id="elm1" name="contenu" rows="18" required><?= $con?></textarea>
							</div>		
						</div>
						<?php echo "<input type='hidden' name='text' value='".$id."'>"; ?>
            		<div class="form-group">
            		 <div class="col-md-4"></div>	
               		 <button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Modifier</button>
             		 </div>

						</form>	
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>