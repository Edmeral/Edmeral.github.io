<?php
	require "inc/header.php";
	if(!isset($_SESSION['privilege']) || $_SESSION['privilege'] != 'admin') exit(0);
	require "models/membres.php" ;
	require "models/equipes.php";

	$membre = get_membre($id);
	$equipes = get_liste_equipes();
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
			<!-- Displaying error/success messages -->
				<?php
					if (isset($_SESSION['slim.flash']['success'])) echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
					if (isset($_SESSION['slim.flash']['error'])) echo '<div class="alert alert-danger" role="alert">'.$_SESSION['slim.flash']['error'].'</div>';
				?>

				<p>
					<h1>&nbsp;&nbsp;&nbsp;Modifier un membre</h1>
					<div class="col-lg-2"></div>
					<div class="col-lg-8">
					<br><br>
						<form class="form-horizontal" role="form" enctype="multipart/form-data" method="POST" action="../modifier-membre/<?= $id ?>">
							<div class="form-group">
								<label class="col-md-2 control-label">Nom :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='nom' value=".$membre['nom'].">" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Prenom :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='prenom' value=".$membre['prenom'].">" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Type :</label>
								<div class="col-md-6">
								<select class="form-control" data-style="btn-white" name="statut" id="statut">
									<option <?= ($membre['statut'] == "Permanent") ? "selected" : "" ?> >Permanent</option>
									<option <?= ($membre['statut'] == "Non-permanent") ? "selected" : "" ?> >Non-permanent</option>
									<option <?= ($membre['statut'] == "Ancien") ? "selected" : "" ?> >Ancien</option>
								</select>
								</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Equipe :</label>
								<div class="col-md-6">
								<select class="form-control" data-style="btn-white" name="equipe">
								<?php
									foreach($equipes as $equipe)
									{
										$opt = '<option value="'.$equipe['equipe_id'].'" ';
										if($equipe['equipe_id'] == $membre['equipe_id'])
											$opt .=' selected';
										$opt .= ' >'.utf8_encode($equipe['libelle']).'</option>'; 
										echo $opt;
									}
								?>
								</select>
								</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Specialité :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='specialite' value=".utf8_encode($membre['specialite']).">" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Grade :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='grade' value=".$membre['grade'].">" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Adresse :</label>
									<div class="col-md-6">
									<?php echo "<textarea class='form-control' name='adresse' rows='5'>".$membre['adresse']."</textarea>" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Photo:</label>
								<div class="col-md-1"></div>
							
								<div class="col-md-4 fileupload	btn btn-default btn-custom btn-rounded waves-effect waves-light">
                                    <span>Modifier la photo</span>
                                  <input type="file" class="upload" name="photo">
                                </div>
                            	</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Email :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='email' value=".$membre['email']." pattern=\"[^ @]*@[^ @]*\">" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Telephone :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='telephone' value=".$membre['telephone'].">" ; ?>
        							</div>
                			</div>
								
								
							<div class="form-group">
	                        		<div class="col-md-3"></div>
	                        		<div class="col-md-3">
	                        			<input type="hidden" name="ID" value="<?= $id ?>" />
	                        			<br><br><button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Enregistrer</button>
	                        		</div>
									
                			</div>
                		</form>	
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>