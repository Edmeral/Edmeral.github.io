<?php
	require "inc/header.php";
	require "controllers/publication.php" ;
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Publication</h1><br><br>
					<div class="row">
						<div class="col-lg-1"></div>
						<div class="col-md-10">		
							<div class="text-muted"><h1><strong><?= $publication['titre'] ?></strong>
							<?php if($pdf_exists) { ?>
								<a href="assets/publications/publication_<?= $publication['id'] ?>.pdf"><i class="md md-file-download"></i></a>
							<?php } ?>
								</h1></div>
								<?= $publication['actifs'] ?><?= $publication['passifs'] ?>
							<div class="text-muted"><h5><em><strong>Date : <?= $publication['annee_publication'] ?> / Type : <?= ucfirst($publication['type']) ?></strong></em></h5></div><br>
							<div class=""></div>
							<p>&nbsp;<?= $publication['resume'] ?></p>
						</div>
					</div>
					<br><br>
					
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>