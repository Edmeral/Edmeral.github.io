<?php
	require "inc/header.php";
	require "controllers/publication.php" ;
	$mois = array(1 => 'Janvier',2 => 'Février',3 => 'Mars',4 => 'Avril',5 => 'Mai',6 => 'Juin',
				  7 => 'Juillet',8 => 'Aout',9 => 'Septembre',10 => 'Octobre',11 => 'Novembre',12 => 'Décembre');
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Publication</h1><br><br>
					<div class="row">
						<div class="col-lg-1"></div>
						<div class="col-md-10">		
							<div class="text-muted"><h1><strong><?= $publication['titre'] ?></strong>
							<?php if($pdf_exists) { ?>
								<a href="assets/publications/publication_<?= $publication['id'] ?>.pdf"><i class="md md-file-download"></i></a>
							<?php } ?>
								</h1>
								<h4><strong>(<?= ucfirst($publication['source_publication']) ?>)</h4><br></div>
							<h4><strong>Auteurs : </strong> <?= $publication['actifs'] ?><?= $publication['passifs'] ?></h4>
							<h4><strong>Date : </strong> <?= $mois[$publication['mois_publication']].' '.$publication['annee_publication'] ?></h4>
							<h4><strong>Lieu : </strong> <?= ucfirst($publication['lieu']) ?></h4>

							<h4><strong>Type : </strong> <?= ucfirst($publication['type']) ?></h4>
							<div class=""></div>
							<h4><strong><br>Résumé : </strong> </h4>
							<p>&nbsp;<?= $publication['resume'] ?></p>
						</div>
					</div>
					<br><br>
					
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>