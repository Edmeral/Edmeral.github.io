<?php
require "inc/header.php";
require "models/publications.php";
if(!isset($_SESSION['privilege']) || ($_SESSION['privilege'] != 'admin' && $_SESSION['privilege'] != 'membre')) exit(0);

$pub = get_publication($id);
$mois = array(1 => 'Janvier',2 => 'Février',3 => 'Mars',4 => 'Avril',5 => 'Mai',6 => 'Juin',
              7 => 'Juillet',8 => 'Aout',9 => 'Septembre',10 => 'Octobre',11 => 'Novembre',12 => 'Décembre');
?>


<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-border panel-custom ">
      <div class="panel-heading">
        <h3 class="panel-title"></h3>
      </div>
      <div class="panel-body">
        <?php
        if (isset($_SESSION['slim.flash']['success'])) echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
        if (isset($_SESSION['slim.flash']['error'])) echo '<div class="alert alert-danger" role="alert">'.$_SESSION['slim.flash']['error'].'</div>';
        ?>
        <p>
        <h1>&nbsp;&nbsp;Modifier une publication</h1><br><br>
        <div class="col-lg-2"></div>
        <div class="col-lg-10">
          <form class="form-horizontal" role="form" enctype="multipart/form-data" method="POST" action="../modifier-publication">

            <div class="form-group">
              <label class="col-md-2 control-label">Titre :</label>
              <div class="col-md-6">
                <input type="text" class="form-control" name="titre" value="<?= $pub['titre'] ?>" required>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-2">Mois :</label>
              <div class="col-md-6">
                <input type="text" class="form-control" name="mois" value="<?= $mois[$pub['mois_publication']] ?>" required>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-2">Année :</label>
              <div class="col-md-6">
                <input type="text" class="form-control" name="annee" value="<?= $pub['annee_publication'] ?>" required>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-2">Lieu :</label>
              <div class="col-md-6">
                <input type="text" class="form-control" name="lieu" value="<?= $pub['lieu'] ?>" required>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-2">Source :</label>
              <div class="col-md-6">
                <input type="text" class="form-control" name="source" value="<?= $pub['source_publication'] ?>" required>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-2">Type :</label>
              <div class="col-md-6">
                <select name="type" class="form-control" data-style="btn-white">
                  <option value="journal" <?= ($pub['type'] == 'journal') ? "selected" : "" ?>>Journal</option>
                  <option value="HDR" <?= ($pub['type'] == 'HDR') ? "selected" : "" ?>>HDR</option>
                  <option value="these" <?= ($pub['type'] == 'these') ? "selected" : "" ?>>Thèse</option>
                  <option value="brevet" <?= ($pub['type'] == 'brevet') ? "selected" : "" ?>>Brevet</option>
                  <option value="autre" <?= ($pub['type'] == 'autre') ? "selected" : "" ?>>Autre</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="col-md-2 control-label">Résumé :</label>
              <div class="col-md-6">
                <textarea class="form-control" name="resume" rows="5"><?= $pub['resume'] ?></textarea>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-2">Document :</label>
              <div class="col-md-6 row">
                <div class="col-md-3"></div>
                <div class="col-md-6 fileupload btn btn-default btn-custom btn-rounded waves-effect waves-light">
                  <span>Choisir un PDF</span>
                  <input type="file" class="upload" name="document">
                </div>  
              </div>
            </div>

            <div class="form-group">
              <div class="col-md-3"></div>
              <div class="col-md-3"><br><br>
                <input type="hidden" name="ID" value="<?= $id ?>">
                <button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">
                  Modifier
                </button>
              </div>
            </div>
          </form>
        </div>

        </p>
      </div>
    </div>
  </div>
</div>


<?php
require "inc/footer.php";
?>

<script src="assets/js/typeahead.js"></script>
<script>
  $.get('membres-json', function (membresObj) {
    /*
     * Typeahead configuration (for autocompletion)
     */
    var substringMatcher = function (strs) {
      return function findMatches(q, cb) {
        var matches, substringRegex;

        // an array that will be populated with substring matches
        matches = [];

        // regex used to determine if a string contains the substring `q`
        substrRegex = new RegExp(q, 'i');

        // iterate through the pool of strings and for any string that
        // contains the substring `q`, add it to the `matches` array
        $.each(strs, function (i, str) {
          if (substrRegex.test(str)) {
            matches.push(str);
          }
        });

        cb(matches);
      };
    };

    var membres = membresObj.map(function (membre) {
      return membre.name
    });

    var membresObj = membresObj.reduce(function (membres, membre) {
      membres[membre.name] = membre.id
      return membres
    }, {})


    function initializeTypeAhead(elem) {
      elem.typeahead({
          hint: true,
          highlight: true,
          minLength: 1
        },
        {
          name: 'membres',
          source: substringMatcher(membres)
        });
    }

    initializeTypeAhead($('.typeahead'))

    $(document).ready(function () {

      $('#add-member-icon').click(function () {
        $('#auteurs').append('<div class="col-md-5 col-md-offset-2 auteur-margin"> <input type="text" class="form-control typeahead" name=> </div>')
        var newField = $('.typeahead').last();
        newField.focus()
        initializeTypeAhead(newField)
      })

      $('form').submit(function (event) {
//        event.preventDefault();
        var membresActives = [];
        var membresPassifs = [];


        $('#auteurs input.form-control.tt-input').each(function() {
          if (membresObj[$(this).val()] == undefined) {
            membresPassifs.push($(this).val())
            $(this).attr('name', 'auteursPassifs[]')
          }
          else {
            membresActives.push(membresObj[$(this).val()])
            $(this).attr('name', 'auteursActives[]')
            $(this).val(membresObj[$(this).val()])
          }
        })

        var form = $('form').serializeArray();
        console.log(form)
//        form.push({ name: 'membres_passifs', value: membresPassifs.join(',') })
//        form.push({ name: 'membres_actives', value: membresActives.join(',') })


//      $.ajax({
//        type: 'POST',
//        url: 'ajouter-publication',
//        data: $.param(form),
//        success: function(data) { console.log('Everything is added!', data); },
//
//      })
      })
    })
  })


</script>
