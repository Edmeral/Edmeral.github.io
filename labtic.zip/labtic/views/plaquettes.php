<?php
	require "inc/header.php";
	require "controllers/accueil.php"
?>

<div class="row">
	<div class="col-lg-6">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title">Plaquette Equipe 1</h3>
			</div>
			<div class="panel-body">
				<p>
					<img class="img-responsive" src="assets/images/plaquette_equipe_1.jpg" />
				</p>
			</div>
		</div>
	</div>

	<div class="col-lg-6">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title">Plaquette Equipe 2</h3>
			</div>
			<div class="panel-body">
				<p>
					<img class="img-responsive" src="assets/images/plaquette_equipe_2.jpg" />
				</p>
			</div>
		</div>
	</div>
</div>


<div class="row">
	<div class="col-lg-6">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title">Plaquette Equipe 3</h3>
			</div>
			<div class="panel-body">
				<p>
					<img class="img-responsive" src="assets/images/plaquette_equipe_3.jpg" />
				</p>
			</div>
		</div>
	</div>

	<div class="col-lg-6">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title">Plaquette Equipe 4</h3>
			</div>
			<div class="panel-body">
				<p>
					<img class="img-responsive" src="assets/images/plaquette_equipe_4.jpg" />
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>