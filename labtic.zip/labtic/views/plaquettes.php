<?php
	require "inc/header.php";
	require "models/equipes.php";

	$equipes = get_liste_equipes();
?>

<?php 
	$counter = 0;
	foreach($equipes as $equipe)
	{
		$counter++;
		if($counter % 2 == 1)
		{
			?>
			<div class="row">
			<div class="col-lg-6">
				<div class="panel panel-border panel-custom">
					<div class="panel-heading">
						<h3 class="panel-title"><?= $equipe['libelle'] ?></h3>
					</div>
					<div class="panel-body">
						<p>
							<a href="equipe/<?= $equipe['equipe_id'] ?>">
							<img class="img-responsive" src="/labtic/assets/images/equipes/plaquette_equipe_<?= $equipe['equipe_id'] ?>.jpg" />
							</a>
						</p>
					</div>
				</div>
			</div>
			<?php
		}
		else
		{
		?>
			<div class="col-lg-6">
				<div class="panel panel-border panel-custom">
					<div class="panel-heading">
						<h3 class="panel-title"><?= $equipe['libelle'] ?></h3>
					</div>
					<div class="panel-body">
						<p>
							<a href="equipe/<?= $equipe['equipe_id'] ?>">
							<img class="img-responsive" src="/labtic/assets/images/equipes/plaquette_equipe_<?= $equipe['equipe_id'] ?>.jpg" />
							</a>
						</p>
					</div>
				</div>
			</div>
		</div>
		<?php
		}
	}
?>


<?php
	require "inc/footer.php";
?>