<?php
	require "inc/header.php";
	if(!isset($_SESSION['privilege']) || $_SESSION['privilege'] != 'membre') exit(0);
	require "models/activites.php";
	$activite = get_activite($id);
	$equipes = get_liste_equipes();
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<h1>Modifier l'activité</h1>
					<div class="row">	
					<div class="col-lg-2"></div>
					<div class="col-lg-9">
						<form class="form-horizontal" role="form" enctype="multipart/form-data" method="POST" action="/labtic/modifier-activite">

                        	<h4 class="m-t-0 header-title"><br><br><br>	Informations sur l'activité: <br><br><br></h4>

							<div class="form-group">
								<label class="col-md-2 control-label">Titre :</label>
									<div class="col-md-6">
									<input type='text' class='form-control' name='titre' value="<?= utf8_encode($activite['titre'])?>" required>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Type :</label>
									<div class="col-md-6">
									<select class="form-control" data-style="btn-white" name="type">
										<option value="Soutenance">Soutenance</option>
										<option value="Seminaire">Séminaire</option>
										<option value="Conference">Conférence</option>
									</select>
        							</div>
                			</div>
							<div class="form-group">
								<label class="col-md-2 control-label">Equipe :</label>
								<div class="col-md-6">
								<select class="form-control" data-style="btn-white" name="equipe">
								<?php
									foreach($equipes as $equipe)
										echo '<option value="'.$equipe['equipe_id'].'">'.utf8_encode($equipe['libelle']).'</option>';
								?>
								</select>
								</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Date de début :</label>
									<div class="col-md-6">
												<input type="text"  class="datepicker form-control" name="date_debut" placeholder="Date début" value="<?= utf8_encode($activite['date_debut']) ?>" required>
												
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Date de fin :</label>
									<div class="col-md-6">
											<input type="text"  class="datepicker form-control" name="date_fin" placeholder="Date fin" value="<?= utf8_encode($activite['date_debut']) ?>" required>
        							</div>
                			</div>
                		<div class="form-group">
                			<label class="col-md-2 control-label">Description :</label>
							<div class="col-md-6">
								<textarea class="form-control" id="elm1" name="description" rows="6"><?= utf8_encode($activite['description']) ?></textarea>
							</div>		
						</div>
                			<input type="hidden" name="id" value="<?= $id ?>">
							<div class="form-group">
	                        		<div class="col-md-3"></div>
	                        		<div class="col-md-3">
	                        			<br><br>
	                        			<button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Modifier</button>
	                        		</div>					
									
                			</div>
                			</div>

                		</form>	
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>