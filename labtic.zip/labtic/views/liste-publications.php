<?php
require "inc/header.php";
require "controllers/publications.php";
?>


  <div class="row">
  <div class="col-lg-12">
    <div class="panel panel-border panel-custom">
      <div class="panel-heading">
        <h3 class="panel-title"></h3>
      </div>
      <div class="panel-body">
        <p>
        <h1>&nbsp;Publications</h1><br>
        <?php
          if (isset($_SESSION['slim.flash']['success'])) echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
        ?>
        <div class="row">
          <div class="col-sm-1">
          </div>
          <div class="col-sm-10">
            <div class="p-20">
              <div class="timeline-1">
                <?php
                $nb_exp = 0;
                $year = "";
                foreach($publications as $publication)
                {
                  $nb_exp++;
                  if($year != $publication['annee_publication'])
                  {
                    $year = $publication['annee_publication'];
                    echo '</div></div>';
                    echo "<h2>".$publication['annee_publication']."</h2>";
                    echo '<div class="p-20"><div class="timeline-1">';
                  }
                  ?>
                  <div class="time-item">
                    <div class="item-info">
                      <div class="text-muted">
                        <?= $publication['actifs'] ?><?= $publication['passifs'] ?>
                        <b><a href="publication/<?= $publication['id'] ?>">« <?= '<b>'.$publication['titre'].'</b></a>' ?> »</a></b>
                        (<?= $publication['annee_publication'] ?>)
                        <?php if(file_exists("assets/publications/publication_".$publication['id'].".pdf"))
                          echo '<a href="assets/publications/publication_'.$publication['id'] .'.pdf"><i class="md md-file-download"></i></a>';
                          if(isset($_SESSION['privilege']) && $_SESSION['privilege'] == 'admin') 
                            echo '<a id="supprimer-link" href="supprimer-publication/<?= $publication[\'id\'] ?>"><i class="md md-close"></i></a>';
                        ?>

                        
                      </div>
                    </div>
                  </div>
                  <?php
                }
                if($nb_exp == 0)
                {
                  ?>
                  <div class="item-info">
                    Aucune publication n'est encore listée.
                  </div>
                  <?php
                }
                ?>
              </div>
            </div>
          </div>
          </p>
        </div>
      </div>
    </div>
  </div>

  <script>

  </script>
<?php
require "inc/footer.php";
?>

    <script>
      $('#supprimer-link').click(function(event) {
        if (!confirm('Êtes vous sûr de vouloir supprimer cette publicaiton?'))
          event.preventDefault()
      })
    </script>
