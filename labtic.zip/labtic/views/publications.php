<?php
	require "inc/header.php";
	require "controllers/publications.php";
?>


<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>&nbsp;Publications</h1><br>
				<div class="row">
				<div class="col-sm-1">
				</div>
				<div class="col-sm-10">
					<div class="p-20">
						<div class="timeline-1">
						<?php
						$nb_exp = 0;
						$year = "";
						$mois = array(1 => 'Janvier',2 => 'Février',3 => 'Mars',4 => 'Avril',5 => 'Mai',6 => 'Juin',
									  7 => 'Juillet',8 => 'Aout',9 => 'Septembre',10 => 'Octobre',11 => 'Novembre',12 => 'Décembre');
						foreach($publications as $publication)
						{
							$nb_exp++;
							if($year != $publication['annee_publication'])
							{
								$year = $publication['annee_publication'];
								echo '</div></div>';
								echo "<h2>".$publication['annee_publication']."</h2>";
								echo '<div class="p-20"><div class="timeline-1">';
							}
							?>
							<div class="time-item">
								<div class="item-info">
									<div class="text-muted">
										<?= $publication['actifs'] ?><?= $publication['passifs'] ?>
										<b><a href="publication/<?= $publication['id'] ?>">« <?= '<b>'.$publication['titre'].'</b></a>' ?> »</a></b>
										<?= '<em style="color:#597070">('.utf8_encode($publication['source_publication']).')</em>' ?>
										&nbsp;<?= $mois[ $publication['mois_publication'] ].', '.$publication['annee_publication'] ?>
										<?= ' - ' . $publication['lieu'] ?>
									<?php if(file_exists("assets/publications/publication_".$publication['id'].".pdf"))
										echo '<a href="assets/publications/publication_'.$publication['id'] .'.pdf"><i class="md md-file-download"></i></a>'
										?>
									</div>
								</div>
							</div>
							<?php
						}
						if($nb_exp == 0)
						{
							?>
							<div class="item-info">
								Aucune publication n'est encore listée.
							</div>
							<?php
						}
						?>

					</div>
				</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					            <div class="card-box">
                        			<h4 class="text-dark header-title m-t-0">Nos publications</h4>

                        			<div class="text-center">
                                        <ul class="list-inline chart-detail-list">
                                            <li>
                                                <h5><i class="fa fa-circle m-r-5" style="color: #5fbeaa;"></i>Journal</h5>
                                            </li>
                                            <li>
                                                <h5><i class="fa fa-circle m-r-5" style="color: #5d9cec;"></i>HDR</h5>
                                            </li>
                                            <li>
                                                <h5><i class="fa fa-circle m-r-5" style="color: #ebeff2;"></i>Thèse</h5>
                                            </li>
                                            <li>
                                                <h5><i class="fa fa-circle m-r-5" style="color: #dcdcdc;"></i>Brevet</h5>
                                            </li>
                                            <li>
                                                <h5><i class="fa fa-circle m-r-5" style="color: #40A497;"></i>Autre</h5>
                                            </li>                                            
                                        </ul>
                                    </div>

                                    <div id="area-example" style="height: 300px;"></div>

                        		</div>
                        		<br><br><br><br><br>
				</div>
			</div>			
				</p>
			</div>

		</div>
	</div>
</div>

<?php
	require "inc/footer.php";

?>


<script type="text/javascript">
/*
 * Play with this code and it'll update in the panel opposite.
 *
 * Why not try some of the options above?
 */
Morris.Line({
  element: 'area-example',
  data: <?php echo $data ?>,
  xkey: 'y',
  ykeys: ['a', 'b','c','d','e'],
  labels: ['journal', 'HDR','these','brevet','autre'],
  lineColors:['#5fbeaa','#5d9cec','#ebeff2','#dcdcdc','#40A497'],
  hideHover :'always',
  pointSize :'3px',
 

	
});
	


</script>