<?php
	require "inc/header.php";
	require "models/membres.php";
	require "models/equipes.php";

	$membre = get_membre($_SESSION['membre_id']);
	$equipes = get_liste_equipes();
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<h1>Ajouter un membre</h1>
					<div class="row">	
					<div class="col-lg-2"></div>
					<div class="col-lg-9">
						<form class="form-horizontal" role="form" enctype="multipart/form-data" method="POST" action="ajouter-membre">

                        	<h4 class="m-t-0 header-title"><br><br><br>	Informations personnelles : <br><br><br></h4>

							<div class="form-group">
								<label class="col-md-2 control-label">Nom :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='nom'>" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Prenom :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='prenom'>" ; ?>
        							</div>
                			</div>
							<div class="form-group">
								<label class="col-md-2 control-label">Equipe :</label>
								<div class="col-md-6">
								<select class="form-control" data-style="btn-white" name="equipe">
								<?php
									foreach($equipes as $equipe)
										echo '<option value="'.$equipe['equipe_id'].'">'.utf8_encode($equipe['libelle']).'</option>';
								?>
								</select>
								</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Specialité :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='specialite'>" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Grade :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='grade'>" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Adresse :</label>
									<div class="col-md-6">
									<?php echo "<textarea class='form-control' name='adresse' rows='5'>".$membre['adresse']."</textarea>" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Email :</label>
								<div class="col-md-6">
								<?php echo "<input type='text' class='form-control' name='email' value='".$membre['email']."' pattern='[^ @]*@[^ @]*'>" ; ?>
    							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Telephone :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='telephone' value=".$membre['telephone'].">" ; ?>
        							</div>
                			</div>
                			<div class="form-group">
								<label class="col-md-2 control-label">Photo:</label>
								<div class="col-md-1"></div>
									<div class="col-md-4 fileupload	btn btn-default btn-custom btn-rounded waves-effect waves-light">
                                        <span>Uploader une photo</span>
                                      <input type="file" class="upload" name="photo">
                                    </div>	
                        	</div>

							<div class="form-group">
								<label class="col-md-2 control-label">Type :</label>
								<div class="col-md-6">
								<select class="form-control" data-style="btn-white" name="type-membre" id="type-membre">
									<option>Permanent</option>
									<option>Non-permanent</option>
								</select>
								</div>
                			</div>

                			<div id="infos-login">
	                        	<h4 class="m-t-0 header-title"><br><br><br>	Informations de connexion : <br><br><br></h4>

	                			<div class="form-group">
									<label class="col-md-2 control-label">Login :</label>
									<div class="col-md-6">
									<?php echo "<input type='text' class='form-control' name='login'>"; ?>
	    							</div>
	                			</div>
	                			<div class="form-group">
									<label class="col-md-2 control-label">Password :</label>
									<div class="col-md-6">
									<?php echo "<input type='password' class='form-control' name='password'>" ; ?>
	    							</div>
	                			</div>
                			</div>

							<div class="form-group">
	                        		<div class="col-md-3"></div>
	                        		<div class="col-md-3">
	                        			<br><br>
	                        			<button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Valider</button>
	                        		</div>					
									
                			</div>
                			</div>

                		</form>	
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>