<?php
	require "inc/header.php";
?>

<div class="row">
	<div class="col-md-5">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="ion-compass"></i>
					&nbsp;&nbsp; Carte
				</h3>
			</div>
			<div class="panel-body text-center">
				<iframe width="350" height="448" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" 
					src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=fr&amp;geocode=&amp;q=ENSA+TANGER&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=39.371738,86.572266&amp;ie=UTF8&amp;hq=ENSA&amp;hnear=Tanger,+Tangier-Assilah,+Tanger-T%C3%A9touan,+Maroc&amp;ll=35.737972,-5.894341&amp;spn=0.063128,0.20755&amp;t=m&amp;output=embed">
				</iframe>
			</div>
		</div>
	</div>

	<div class="col-md-7">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="ion-android-mail"></i>
					&nbsp;&nbsp; Contact
				</h3>
			</div>
			<div class="panel-body">
				<form class="form-horizontal" role="form" method="POST" action="contact">                                    
					<div class="form-group">
						<label class="col-md-2 control-label">Nom</label>
						<div class="col-md-10">
							<input type="text" class="form-control" name="nom" value="Nom">
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-2 control-label" for="example-email">E-mail</label>
						<div class="col-md-10">
							<input type="email" id="example-email" name="email" class="form-control" placeholder="E-mail">
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-2 control-label">Message</label>
						<div class="col-md-10">
							<textarea class="form-control" rows="5" name="message"></textarea>
						</div>
					</div>
					<div class="form-group">
						<div class="col-md-5">
						</div>
						<div class="col-md-2">
							<button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Envoyer</button>
						</div>
					</div>

					<div class="form-group">
						<div class="col-md-1">
						</div>
						<div class="col-md-10">
						<p class="text-muted m-b-30 font-13">
							<br><br>
							<strong>Adresse</strong>: BP 1818 Tanger Principal Tanger<br>
							<strong>Téléphone</strong>: (0539) 39 37 44<br>
							<strong>Fax</strong>: (0539) 39 37 44<br>
							<strong>Email</strong>: info@ensat.ac.ma <br>
						</p>
					</div>
				</form>
			</div>
		</div>
	</div>

	<div class="clearfix"></div>
	</div>
</div>	

<?php
	require "inc/footer.php";
?>