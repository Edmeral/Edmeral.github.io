<?php
	require "inc/header.php";
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Projets</h1>
					<br><br><br><br><br><br>
					<br><br><br><br><br><br>
					<br><br><br><br><br><br>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>