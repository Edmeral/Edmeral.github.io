<?php
	require "inc/header.php";
	require "controllers/equipes.php";
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Equipes du Labtic</h1>
					<br>
					<div class="row">
					<div class="col-lg-1"></div>
						<div class="col-lg-10">
						<?php if (isset($_SESSION['slim.flash']['success']))
							echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
						?>
						<?= $table_equipes ?>
					<br><br><br><br><br><br><br>
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>