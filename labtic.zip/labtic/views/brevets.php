<?php
require "inc/header.php";
require "controllers/brevets.php";
?>


  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-border panel-custom">
        <div class="panel-heading">
          <h3 class="panel-title"></h3>
        </div>
        <div class="panel-body">
          <p>
          <h1>Brevets</h1><br><br>
          <div class="p-20">
            <div class="timeline-1">

              <?php
              $nb_exp = 0;
              foreach($publications as $publication)
              {
                $nb_exp++;
                ?>
              <div class="time-item">
                <div class="item-info">
                  <div class="text-muted">
                    <?= $publication['actifs'] ?><?= $publication['passifs'] ?>
                    <b><a href="publication/<?= $publication['id'] ?>">« <?= $publication['titre'] ?> »</a></b>
                    (<?= $publication['annee_publication'] ?>)
                  <?php if(file_exists("assets/publications/publication_".$publication['id'].".pdf"))
                    echo '<a href="assets/publications/publication_'.$publication['id'] .'.pdf"><i class="md md-file-download"></i></a>'
                    ?>
                  </div>
                </div>
              </div>
                <?php
              }

              if($nb_exp == 0)
              {

                ?>
                <div class="item-info">
                  Aucun brevet n'est encore listé.
                </div>
                <?php
              }
              ?>
            </div>
          </div>
          </p>
        </div>
      </div>
    </div>
  </div>

<?php
require "inc/footer.php";
?>