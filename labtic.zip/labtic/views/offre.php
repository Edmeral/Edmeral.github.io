<?php
	require "inc/header.php";
	require "controllers/offre.php";
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
			<div class="row">
			<div class="col-sm-2"></div>
			<div class="col-sm-8">
				<p>
					<h1><?= utf8_encode($offre['titre']) ?></h1><br>
					<div class="text-muted">
					<h4><b>Date : </b>  <?= $offre['date_offre'] ?>
					</h4></div>
					<div class="text-muted">
					<h4><b>Description : </b> </h4>
					<div><?= $offre['description'] ?></div>
					</div>
				<div>
				<br><br><br><br>
				</div>
				</br>
				</p>
			</div>
		</div>
	</div>
</div>
