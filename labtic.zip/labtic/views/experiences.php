<?php
	require "inc/header.php";
	require "controllers/experiences.php";
?>
<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<div class="row">
				<div class="col-lg-12">
					<h4 class="m-t-0 header-title"><b>Mes epériences</b></h4>
					<?php if (isset($_SESSION['slim.flash']['success']))
						echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
					?>
					<div class="p-20">
						<div class="table-responsive">
							<?= $table_experiences ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>