<?php
	require "inc/header.php";
	require "controllers/membres.php"
?>

<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<div class="row">
				<div class="col-lg-12">
					<h4 class="m-t-0 header-title"><b>Membres du LabTIC</b></h4>
					<div class="p-20">
						<?php if (isset($_SESSION['slim.flash']['success']))
							echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
						?>
						<div class="table-responsive">
							<?= $table_membres ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>