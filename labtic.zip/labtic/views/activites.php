<?php
	require "inc/header.php";
	require 'controllers/activites.php';
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>&nbsp;&nbsp;Activités</h1>
					<br>
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-10">
							<?php if (isset($_SESSION['slim.flash']['success']))
								echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
							?>
							<table class="table m-0">
								<thead>
									<th width="85%">Titre</th>
									<th width="15%">Options</th>
								</thead>
								<tbody>
									<?= $affichage ?>
								</tbody>
							</table>
						</div>
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>