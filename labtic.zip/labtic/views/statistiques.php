<?php
require "inc/header.php";
require "controllers/statistiques.php";
?>

<!-- Page-Title -->
<div class="row">
	<div class="col-sm-12">
		<h2 class="page-title">Statistiques</h2>
		<p class="text-muted page-title-alt"></p>
	</div>
</div>

<div class="row">
	<div class="col-lg-4">
		<div class="widget-bg-color-icon card-box fadeInDown animated">
			<div class="bg-icon bg-icon-info pull-left">
				<i class="ion-person-stalker text-info"></i>
			</div>
			<div class="text-right">
				<p class="text-muted">Nombre de membres	</p>
				<h3 class="text-dark"><b class="counter"><?= $total_membres ?></b></h3>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>


	<div class="col-lg-4">
		<div class="widget-bg-color-icon card-box">
			<div class="bg-icon bg-icon-purple pull-left">
				<i class="ion-document text-purple"></i>
			</div>
			<div class="text-right">
				<p class="text-muted">Publications</p>
				<h3 class="text-dark"><b class="counter"><?= $total_pub ?></b></h3>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>

	<div class="col-lg-4">
		<div class="widget-bg-color-icon card-box">
			<div class="bg-icon bg-icon-success pull-left">
				<i class="md md-event text-success"></i>
			</div>
			<div class="text-right">
				<p class="text-muted">Nombre d'activités</p>
				<h3 class="text-dark"><b class="counter"><?= $total_ev ?></b></h3>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>

<div class="row">

	<div class="col-lg-4">
		<div class="card-box">
			<h4 class="text-dark header-title m-t-0 m-b-30">Recherche</h4>

			<div class="widget-chart text-center">
				<h5 class="text-muted m-t-20">Recherhces cette année</h5>
				<?php
				if(isset($stats[date("Y")]))
				{
					$d = $stats[date("Y")];
				}
				else
				{
					$d = array();
					$d['p'] = $d['h'] = $d['t'] = $d['a'] = $d['b'] = 0;
				}
				$total = $d['p'] + $d['h'] + $d['t'] + $d['a'] + $d['b'];
				?>
				<h2 class="font-600"><?= $total ?> publication</h2>
				<ul class="list-inline m-t-15">
					<li>
						<h5 class="text-muted m-t-20">Journaux</h5>
						<h4 class="m-b-0"><?= $d['p'] ?></h4>
					</li>
					<li>
						<h5 class="text-muted m-t-20">Thèses</h5>
						<h4 class="m-b-0"><?= $d['t'] ?></h4>
					</li>
				</ul>
				<ul class="list-inline m-t-15">
					<li>
						<h5 class="text-muted m-t-20">HDR</h5>
						<h4 class="m-b-0"><?= $d['h'] ?></h4>
					</li>
					<li>
						<h5 class="text-muted m-t-20">Brevets</h5>
						<h4 class="m-b-0"><?= $d['t'] ?></h4>
					</li>
				</ul>
				<ul class="list-inline m-t-15">
					<li>
						<h5 class="text-muted m-t-20">Autres</h5>
						<h4 class="m-b-0"><?= $d['a'] ?></h4>
					</li>
				</ul>
			</div>
		</div>

	</div>

	<div class="col-lg-8">
		<div class="card-box">
			<h4 class="text-dark header-title m-t-0">Nombre de publications par an</h4>
			<div class="text-center">
				<ul class="list-inline chart-detail-list">
					<li>
						<h5><i class="fa fa-circle m-r-5" style="color: #5fbeaa;"></i>Journal</h5>
					</li>
					<li>
						<h5><i class="fa fa-circle m-r-5" style="color: #5d9cec;"></i>Thèses</h5>
					</li>
					<li>
						<h5><i class="fa fa-circle m-r-5" style="color: #dcdcdc;"></i>HDR</h5>
					</li>
					<li>
						<h5><i class="fa fa-circle m-r-5" style="color: #ef6896;"></i>Brevets</h5>
					</li>
					<li>
						<h5><i class="fa fa-circle m-r-5" style="color: #7166ba;"></i>Autres</h5>
					</li>
				</ul>
			</div>
			<div id="morris-bar-stacked" style="height: 303px;"></div>
		</div>
	</div>



</div>

<?php
require "inc/footer.php";
?>
<script>
!function($) {
    "use strict";

    var Dashboard1 = function() {
    	this.$realData = [
    		<?php
	    		$s = '';
	    		foreach($stats as $d)
	    			$s .= "{ y: '".$d['y']."', p: ".$d['p'].",  t: ".$d['t'].", h: ".$d['h'].", b: ".$d['b'].", a: ".$d['a']." },";
	    		echo $s;
	        ?>
    		];
    };
    
    //creates Stacked chart
    Dashboard1.prototype.createStackedChart  = function(element, data, xkey, ykeys, labels, lineColors) {
        Morris.Bar({
            element: element,
            data: data,
            xkey: xkey,
            ykeys: ykeys,
            stacked: true,
            labels: labels,
            hideHover: 'auto',
            resize: true, //defaulted to true
            gridLineColor: '#eeeeee',
            barColors: lineColors
        });
    },

    //creates area chart with dotted
    Dashboard1.prototype.createAreaChartDotted = function(element, pointSize, lineWidth, data, xkey, ykeys, labels, Pfillcolor, Pstockcolor, lineColors) {
        Morris.Area({
            element: element,
            pointSize: 0,
            lineWidth: 0,
            data: data,
            xkey: xkey,
            ykeys: ykeys,
            labels: labels,
            hideHover: 'auto',
            pointFillColors: Pfillcolor,
            pointStrokeColors: Pstockcolor,
            resize: true,
            gridLineColor: '#eef0f2',
            lineColors: lineColors
        });

   },
    
    
    Dashboard1.prototype.init = function() {

        //creating Stacked chart
        var $stckedData  = [
            { y: '2005', a: 45, b: 180, c: 100 },
            { y: '2006', a: <?= '250' ?>,  b: 65, c: 80 },
            { y: '2007', a: 100, b: 90, c: 56 }
        ];
        this.createStackedChart('morris-bar-stacked', this.$realData, 'y', ['p', 't', 'h', 'b', 'a'], 
        							['Publications ', 'Thèses ', 'HDR', 'Brevets', 'Autres'],
        							['#5fbeaa', '#5d9cec','#ebeff2', '#ef6896', '#7166ba']);

        //creating area chart
        var $areaDotData = [
                { y: '2009', a: 10, b: 20, c:30 },
                { y: '2010', a: 75,  b: 65, c:30 },
                { y: '2011', a: 50,  b: 40, c:30 },
                { y: '2012', a: 75,  b: 65, c:30 },
                { y: '2013', a: 50,  b: 40, c:30 },
                { y: '2014', a: 75,  b: 65, c:30 },
                { y: '2015', a: 90, b: 60, c:30 }
            ];
        this.createAreaChartDotted('morris-area-with-dotted', 0, 0, $areaDotData, 'y', ['p', 't', 'h', 'b', 'a'], 
        							['Publications ', 'Thèses ', 'HDR ', 'Brevets', 'Autres'],['#ffffff'],['#999999'], 
        							['#5fbeaa', '#5d9cec','#ebeff2', '#ef6896', '#e3e0f1']);

    },
    //init
    $.Dashboard1 = new Dashboard1, $.Dashboard1.Constructor = Dashboard1
}(window.jQuery),

//initializing 
function($) {
    "use strict";
    $.Dashboard1.init();
}(window.jQuery);
</script>