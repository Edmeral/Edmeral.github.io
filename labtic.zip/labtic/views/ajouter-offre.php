<?php
	require "inc/header.php";
	if(!isset($_SESSION['privilege']) || $_SESSION['privilege'] != 'admin') exit(0);
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Ajouter une offre </h1>
				<?php
				if (isset($_SESSION['slim.flash']['success'])) echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
				if (isset($_SESSION['slim.flash']['error'])) echo '<div class="alert alert-danger" role="alert">'.$_SESSION['slim.flash']['error'].'</div>';
				?>
					<br><br>
					<div class="col-md-2"></div>
					<div class="col-md-8">
						<form  class="form-horizontal" role="form" method="POST" action="ajouter-offre" enctype="multipart/form-data">
							<div class="form-group">
	                            <label class="col-md-2 control-label">Titre :</label>
	                                <div class="col-md-6">
	                                    <input type="text" class="form-control" name="titre" placeholder="Titre ..." required> 
	                                </div>
	                        </div>
	                        <div class="form-group">
			                        <label class="control-label col-md-2">Date :</label>
			                            <div class="col-md-6">
			                             	<input type="text" class="datepicker form-control" name="date_offre" placeholder="mm/dd/yyyy" id="datepicker" required>
			                			</div>
			                </div>
			                <div class="form-group">
	                                <label class="col-md-2 control-label">Description :</label>
	    								<div class="col-md-6">
	                                       	<textarea class="form-control" name="description" rows="5" ></textarea>
	                                    </div>
	                        </div>
			                <div class="form-group">
	                                <label class="col-md-2 control-label">Type :</label>
	    								<div class="col-md-6">
	                                       	<select class="form-control" name="type" required>
	                                       		<optgroup label="Postes">
	                                       			<option value="poste enseignant">Poste Enseignant</option>
	                                       			<option value="poste ingenieur">Poste Ingenieur</option>
	                                       		</optgroup>
	                                       		<optgroup label="Sujets">
	                                       			<option value="sujet these">Sujet Thèse</option>
	                                       			<option value="sujet stage">Sujet Stage</option>
	                                       		</optgroup>
	                                       	</select>
	                                    </div>
	                        </div>
	                    	<div class="form-group">
								<label class="col-md-2 control-label">Fichier:</label>
								<div class="col-md-6">

								
									<div class="fileupload	btn btn-default btn-custom btn-rounded waves-effect waves-light">
                                        <span>Ajouter un fichier</span>
                                      <input type="file" class="upload" name="nom_fichier">
                                    </div>	
                                </div>
                            </div>                    	                        
							<div class="form-group">
	                        		<div class="col-md-3"></div>
	                        		<div class="col-md-3">
	                        			<button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Ajouter</button>
	                        		</div>								
									
                			</div>

						</form>
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>