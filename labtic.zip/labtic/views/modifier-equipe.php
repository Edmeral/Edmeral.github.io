<?php
	require "inc/header.php";
	require "models/equipes.php";
	require "models/membres.php";

	$membres = get_liste_permanents();
	$equipe = get_equipe($id);
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Modifier une équipe </h1>
					<br><br>
					<div class="col-md-2"></div>
					<div class="col-md-8">
						<form  class="form-horizontal" role="form" method="POST" action="../modifier-equipe" enctype="multipart/form-data">
							<div class="form-group">
	                            <label class="col-md-2 control-label">Libellé :</label>
	                                <div class="col-md-6">
	                                    <input type="text" class="form-control" name="libelle" value="<?= $equipe['libelle'] ?>" required> 
	                                </div>
	                        </div>
	                        <div class="form-group">
	                            <label class="col-md-2 control-label">Thème :</label>
	                                <div class="col-md-6">
	                                    <input type="text" class="form-control" name="theme" value="<?= $equipe['theme'] ?>" required> 
	                                </div>
	                        </div>
			                <div class="form-group">
	                                <label class="col-md-2 control-label">Description :</label>
	    								<div class="col-md-6">
	                                       	<textarea class="form-control" name="description" rows="5" ><?= $equipe['description'] ?></textarea>
	                                    </div>
	                        </div>
	                        <div class="form-group">
	                            <label class="col-md-2 control-label">Logo :</label>
	                            <div class="col-md-1"></div>
	                                <div class="col-md-4 fileupload	btn btn-default btn-custom btn-rounded waves-effect waves-light">
                                        <span>Choisir un logo</span>
                                      <input type="file" class="upload" name="photo-logo">
                                    </div>	
	                        </div>
	                        <div class="form-group">
	                            <label class="col-md-2 control-label">Plaquette :</label>
	                            <div class="col-md-1"></div>
	                                <div class="col-md-4 fileupload	btn btn-default btn-custom btn-rounded waves-effect waves-light">
                                        <span>Choisir une plaquette</span>
                                      <input type="file" class="upload" name="photo-plaquette">
                                    </div>	
	                        </div>
	                        <div class="form-group">
	                            <label class="col-md-2 control-label">Responsable:</label>
	                                <div class="col-md-6">
	                                    <select class="form-control" data-style="btn-white" name="responsable">
										<?php
											$membres = get_liste_permanents();
											foreach($membres as $membre)
											{
												echo '<option value="'.$membre['membre_id'].'"';
												if($membre['membre_id'] == $equipe['id_responsable'])
													echo ' selected';
												echo '>'.utf8_encode($membre['nom']).' '.utf8_encode($membre['prenom']).'</option>';
											}
										?>
										</select>
	                                </div>
	                        </div>
	                        <div class="form-group">
                        		<div class="col-md-3"></div>
                        		<div class="col-md-3">
                        		<input type="hidden" name="equipe_id" value="<?= $id ?>">
                        			<br><button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Valider</button>
                        		</div>	
						</form>
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>