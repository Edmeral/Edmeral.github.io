<?php
	require "inc/header.php";
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
        <?php if ($this->data['error'])
          echo '<div class="alert alert-danger" role="alert">'.$this->data['error'].'</div>'
        ?>
        <?php if ($this->data['success'])
          echo '<div class="alert alert-success" role="alert">'.$this->data['success'].'</div>'
        ?>
				<p>
					<h1>Changer le mot de passe </h1>
					<br><br>
					<div class="col-lg-2"></div>
					<div class="col-lg-8">
						<form class="form-horizontal" role="form" method="POST" action="changer-mdp">
	                        <div class="form-group">
	                            <label class="col-md-4 control-label">Ancien mot de passe :</label>
	                                <div class="col-md-4">
	                                    <input type="password" class="form-control" name="mdp" placeholder="Ancien mot de passe.." required>
	                                </div>
	                        </div>
	                        <div class="form-group">
	                            <label class="col-md-4 control-label">Nouveau mot de passe :</label>
	                                <div class="col-md-4">
	                                    <input type="password" class="form-control" name="nv_mdp_1" placeholder="Nouveau mot de passe .." required>
	                                </div>
	                        </div>
	                        <div class="form-group">
	                            <label class="col-md-4 control-label">Confirmer mot de passe :</label>
	                                <div class="col-md-4">
	                                    <input type="password" class="form-control" name="nv_mdp_2" placeholder="Confirmer mot de passe .." required>
	                                </div>
	                        </div>
	                        <div class="form-group">
	                        		<div class="col-md-5"></div>
	                        		<div class="col-md-3">
	                        			<button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Modifier</button>
	                        		</div>
	                        </div>
						</form>
					</div>

				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>