<?php
	require "inc/header.php";
	require "controllers/accueil.php" ;
?>
		<div class="row" style="display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display:         flex;">
			<div class="col-lg-4">
			<div class="panel panel-border panel-custom" style="min-height:300px">
				<!-- Default panel contents -->
				<div class="panel-heading">
					<h3 class="panel-title">
						<i class="ion-ios7-calendar-outline"></i>
						&nbsp;&nbsp; Dernières Actualités
					</h3>
				</div>
				<div class="panel-body inner-padding">
					<?= $actualites ?>
				</div>
			</div>
			</div>

			<div class="col-lg-5">
			<div class="panel panel-border panel-danger" style="min-height:300px">
				<!-- Default panel contents -->
				<div class="panel-heading">
					<h3 class="panel-title">
						<i class="md-view-list"></i>
						&nbsp; Dernières Publications
					</h3>
				</div>
				<div class="panel-body inner-padding">
					<?= $publications ?>
				</div>
			</div>
			</div>

			<div class="col-lg-3">
			<div class="panel panel-border panel-primary" style="min-height:300px">
				<!-- Default panel contents -->
				<div class="panel-heading">
					<h3 class="panel-title">
						<i class="ion-university"></i>
						&nbsp;&nbsp; Offres
					</h3>
				</div>
				<div class="panel-body inner-padding">
					<?= $offres ?>
				</div>
				<br>
			</div>
			</div>
		</div>


		<div class="row">
			<div class="col-lg-12">
			<div class="panel panel-border panel-custom">
				<!-- Default panel contents -->
				<div class="panel-heading">
					<h3 class="panel-title">
						<i class="ion-ios7-calendar-outline"></i>
						&nbsp;&nbsp; Mot du directeur
					</h3>
				</div>
				<div class="panel-body inner-padding">
					<?= $mot_directeur ?>
				</div>
			</div>
			</div>
		</div>

</div>


<?php
	require "inc/footer.php";
?>