<?php
	require "inc/header.php";
	require "controllers/anciens.php"
?>

<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<div class="row">
				<div class="col-lg-12">
					<h4 class="m-t-0 header-title"><b>Liste des anciens membres de Labtic</b></h4>
					<div class="p-20">
						<div class="table-responsive">
							<?= $table_anciens ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>
