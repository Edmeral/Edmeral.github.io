<?php
	require "inc/header.php";
	require "controllers/membre.php"
?>
<div class="row" xmlns="http://www.w3.org/1999/html">
		<div class="col-md-4">
			<div class="card-box m-t-20">
				<div class="profile-info-name text-center">
					<img src="/labtic/assets/images/membres/photo_<?= $membre['membre_id'] ?>.jpg" class="img-thumbnail" alt="profile-image" width="100px">
					<h4 class="m-b-5"><b><?= $membre['nom'] . ' ' . $membre['prenom'] ?></b></h4>
					<p class="text-muted"><i class="fa fa-map-marker"></i> <?= $membre['adresse'] ?><br><br></p>
				</div>
				<h4 class="m-t-0 header-title" style="display:inline;"><b>Informations personnelles </b> &nbsp;
				<?php if($owner) echo '<a href="../profil"><i class="fa fa-pencil"></i></a>'; ?>
				<?php if($isAdmin) echo '<a href="../modifier-membre/'.$id.'"><i class="fa fa-pencil"></i></a>'; ?>
				</h4>
				<div class="p-20">

					<div class="about-info-p">
						<strong>Nom complet :</strong>
						<br>
						<p class="text-muted"><?= $membre['nom'] . ' ' . $membre['prenom'] ?></p>
					</div>
					<div class="about-info-p">
						<strong>Téléphone :</strong>
						<br>
						<p class="text-muted"><?= $membre['telephone'] ?></p>
					</div>
					<div class="about-info-p">
						<strong>Email</strong>
						<br>
						<p class="text-muted"><?= $membre['email'] ?></p>
					</div>
					<div class="about-info-p m-b-0">
						<strong>Statut</strong>
						<br>
						<p class="text-muted"><?= $membre['statut'] ?></p>
					</div>
					<div class="about-info-p m-b-0">
						<strong>Specialité</strong>
						<br>
						<p class="text-muted"><?= $membre['specialite'] ?></p>
					</div>
					<div class="about-info-p m-b-0">
						<strong>Equipe</strong>
						<br>
						<p class="text-muted"><?= utf8_encode(get_nom_equipe($membre['equipe_id'])) ?></p>
					</div>
					<div class="about-info-p m-b-0">
						<strong>Location</strong>
						<br>
						<p class="text-muted"><?= $membre['adresse'] ?></p>
					</div>
				</div>
			</div>

		</div>


		<div class="col-md-8">

			<div class="card-box m-t-20">
			<h4 class="m-t-0 header-title"><b>Expériences</b> &nbsp; 
			<?php if($owner) echo '<a href="../experiences/'.$membre['membre_id'].'"><i class="fa fa-pencil"></i></a>'; ?>
			</h4>
			<div class="p-20">
				<div class="timeline-2">
				<?php
					$nb_exp = 0;
					foreach($experiences as $exp)
					{
						$nb_exp++;
					?>
					<div class="time-item">
						<div class="item-info">
							<div class="text-muted"><?= $exp['date_exp'] ?> - <?= utf8_encode($exp['date_fin_exp']) ?></div>
							<p><h4><b><?= $exp['experience'] ?></b></h4></p>
							<p><em><?= $exp['description'] ?></em><br><br></p>
						</div>
					</div>
					<?php
					}

					if($nb_exp == 0)
					{
					?>
						<div class="item-info">
							Aucune expérience n'a été encore listée.
						</div>
					<?php
					}
				?>
				</div>
			</div>
			</div>

			<div class="card-box m-t-20">
			<h4 class="m-t-0 header-title"><b>Publications</b> &nbsp; 
			<?php if($owner) echo '<a href="../publications/'.$membre['membre_id'].'"><i class="fa fa-pencil"></i></a>'; ?>
			</h4>
			<div class="p-20">
				<div class="timeline-1">
				<?php
					$nb_pub = count($publications);
					foreach($publications as $publication)
					{
						?>
						<div class="time-item">
							<div class="item-info">
								<div class="text-muted">
	              				<?= $publication['actifs'] ?><?= $publication['passifs'] ?>

								(<?= $publication['annee_publication'] ?>)
								<?php if(file_exists("../assets/publications/publication_".$publication['id'].".pdf"))
	              					echo '<a href="../assets/publications/publication_'.$publication['id'].'.pdf"><i class="md md-file-download"></i></a>';
	              					?>
								</div>
								<p><h4>
								<b><?= ucfirst($publication['type']) ?> :  </b>
								<b><a href="../publication/<?= $publication['id'] ?>">« <?= $publication['titre'] ?> »</a></b></h4></p>
								<p><?= ucfirst($publication['resume']) ?><br><br></p>
							</div>
						</div>
						<?php
					}
					if($nb_pub == 0)
					{
					?>
						<div class="item-info">
							Aucune publication n'est encore listée.
						</div>
					<?php
					}
				?>
				</div>
			</div>
			</div>
		</div>

			<div class="clearfix"></div>
			</div>
		</div>
	</div>

<?php
	require "inc/footer.php";
?>