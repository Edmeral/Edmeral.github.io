<?php
	require "inc/header.php";
	require "models/experiences.php" ;
	$exp = get_experience($id);
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom ">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Modifier une expérience</h1><br><br>
					<div class="col-lg-2"></div>
					<div class="col-lg-8">
						<form class="form-horizontal" role="form" method="POST" action="../modifier-experience">                                    
	                        <div class="form-group">
	                            <label class="col-md-2 control-label">Experience :</label>
	                                <div class="col-md-6">
	                                    <input type="text" class="form-control" name="experience" value="<?= $exp['experience'] ?>" required> 
	                                </div>
	                        </div>
	                        <div class="form-group">
			                        <label class="control-label col-md-2">Date Début :</label>
			                            <div class="col-md-6">
			                               <div class="input-group">
												<input type="text" class="form-control" name="date_exp" value="<?= $exp['date_exp'] ?>" required>
												<span class="input-group-addon bg-custom b-0 text-white"><i class="icon-calender"></i></span>

			                				</div>
			                			</div>
			                </div>				
	                        <div class="form-group">
			                        <label class="control-label col-md-2">Date Fin :</label>
			                            <div class="col-md-6">
			                               <div class="input-group">
												<input type="text" class="form-control" name="date_fin_exp" value="<?= utf8_encode($exp['date_fin_exp']) ?>" required>
												<span class="input-group-addon bg-custom b-0 text-white"><i class="icon-calender"></i></span>

			                				</div>
			                			</div>
			                </div>				                                
	                         <div class="form-group">
	                                <label class="col-md-2 control-label">description :</label>
	    								<div class="col-md-6">
	                                       	<textarea class="form-control" name="description" rows="5"><?= $exp['description'] ?></textarea>
	                                    </div>
	                        </div>

	                        <div class="form-group">
	                        		<div class="col-md-3"></div>
	                        		<div class="col-md-3">
	                        			<input type="hidden" name="experience_id" value="<?= $exp['experience_id'] ?>" />
	                        			<button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Modifier</button>
	                        		</div>
	                        </div>    
	                    </form>            
					</div>

				</p>
			</div>
		</div>
	</div>
</div>


<?php
	require "inc/footer.php";
?>