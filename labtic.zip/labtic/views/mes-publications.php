<?php
	require "inc/header.php";
	require "controllers/mes-publications.php";
?>


<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>&nbsp;Publications</h1><br>
				<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-10">
				<div class="p-20">
					<div class="timeline-1">

						<?php
						$nb_exp = 0;
						foreach($publications as $publication)
						{
							$nb_exp++;
							?>
							<div class="time-item">
								<div class="item-info">
									<div class="text-muted">
										<?= str_replace("membre/", "/labtic/membre/", $publication['actifs']) ?>
										<?= $publication['passifs'] ?>
										<b><a href="../publication/<?= $publication['id'] ?>">« <?= '<b>'.$publication['titre'].'</b></a>' ?> »</a></b>
										(<?= $publication['annee_publication'] ?>)
									<?php if(file_exists("../assets/publications/publication_".$publication['id'].".pdf"))
										echo '<a href="assets/publications/publication_'.$publication['id'] .'.pdf"><i class="md md-file-download"></i></a>'
										?>
										<br><br>
									</div>
									<div class="row">
									<div class="col-sm-1"></div>
									<div class="col-sm-2">
										<a href="../labtic/modifier-publication/<?= $publication['id']; ?>">
										<i class="fa fa-pencil"></i> Modifier</a>
									</div>
									<div class="col-sm-2">
										<a href="../labtic/supprimer-experience/<?= $publication['id']; ?>"
										onclick="return confirm('Etes-vous sûrs de vouloir supprimer cette publication ?')">
										<i class="fa fa-trash-o"></i> Supprimer</a>
									</div>
									<br><br>
									</div>
								</div>
							</div>
							<?php
						}
						if($nb_exp == 0)
						{
							?>
							<div class="item-info">
								Aucune publication n'est encore listée.
							</div>
							<?php
						}
						?>
					</div>
				</div>
				</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>