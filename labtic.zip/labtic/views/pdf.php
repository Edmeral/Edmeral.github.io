<?php
	require "inc/header.php";
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1><?= $id ?></h1><br><br>
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-8">
							<?php echo"<iframe src='/labtic/assets/offres/".$id."' width='800px' height='600px'align='center'></iframe>" ; ?>
						</div>
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>