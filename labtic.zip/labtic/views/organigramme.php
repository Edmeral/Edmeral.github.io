<?php
	require "inc/header.php";
	require "controllers/accueil.php"
?>

		<div class="panel panel-color panel-custom">
			<!-- Default panel contents -->
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="ion-ios7-keypad"></i>
					&nbsp;&nbsp; Organigramme
				</h3>
			</div>
			<div class="panel-body inner-padding">
				<img class="img-responsive" src="assets/images/organigramme.jpg" />
			</div>
			<br>
		</div>

<?php
	require "inc/footer.php";
?>