<?php
	require "inc/header.php";
	require "controllers/a-propos.php"
?>

	<div class="panel panel-color panel-custom">
		<div class="panel-heading">
			<h3 class="panel-title">
				<i class="ion-arrow-right-b"></i>
				&nbsp;&nbsp; A propos de LabTIC
			</h3>
		</div>
		<div class="panel-body">
			<?= $a_propos ?>
		</div>
	</div>	

	<div class="panel panel-color panel-custom">
		<div class="panel-heading">
			<h3 class="panel-title">
				<i class="ion-arrow-right-b"></i>
				&nbsp;&nbsp; Qui sommes nous ?
			</h3>
		</div>
		<div class="panel-body">
			<div class="text-center">
				<img class="img-thumbnail" src="assets/images/monde.png" />
			</div>
		</div>
	</div>	

<?php
	require "inc/footer.php";
?>