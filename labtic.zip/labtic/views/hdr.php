<?php
require "inc/header.php";
require "controllers/hdr.php";
?>


<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-border panel-custom">
      <div class="panel-heading">
        <h3 class="panel-title"></h3>
      </div>
      <div class="panel-body">
        <p>
          <h1>HDR</h1><br><br>
          <div class="p-20">
            <div class="timeline-1">

              <?php
              $nb_exp = 0;
              $nb_exp = 0;
              $year = "";
              $mois = array(1 => 'Janvier',2 => 'Février',3 => 'Mars',4 => 'Avril',5 => 'Mai',6 => 'Juin',
                7 => 'Juillet',8 => 'Aout',9 => 'Septembre',10 => 'Octobre',11 => 'Novembre',12 => 'Décembre');
              foreach($publications as $publication)
              {
                $nb_exp++;
                if($year != $publication['annee_publication'])
                {
                  $year = $publication['annee_publication'];
                  echo '</div></div>';
                  echo "<h2>".$publication['annee_publication']."</h2>";
                  echo '<div class="p-20"><div class="timeline-1">';
                }
                ?>
                <div class="time-item">
                  <div class="item-info">
                    <div class="text-muted">
                      <?= $publication['actifs'] ?><?= $publication['passifs'] ?>
                      <b><a href="publication/<?= $publication['id'] ?>">« <?= '<b>'.$publication['titre'].'</b></a>' ?> »</a></b>
                      <?= '<em style="color:#597070">('.utf8_encode($publication['source_publication']).')</em>' ?>
                      &nbsp;<?= $mois[ $publication['mois_publication'] ].', '.$publication['annee_publication'] ?>
                      <?= ' - ' . $publication['lieu'] ?>
                      <?php if(file_exists("assets/publications/publication_".$publication['id'].".pdf"))
                      echo '<a href="assets/publications/publication_'.$publication['id'] .'.pdf"><i class="md md-file-download"></i></a>'
                      ?>
                    </div>
                  </div>
                </div>
                <?php
              }

              if($nb_exp == 0)
              {

                ?>
                <div class="item-info">
                  Aucune habilitation n'est encore listée.
                </div>
                <?php
              }
              ?>
            </div>
          </div>
        </p>
      </div>
    </div>
  </div>
</div>

<?php
require "inc/footer.php";
?>