<?php
	require "inc/header.php";
	require "controllers/presentation.php"
?>
		<div class="panel panel-color panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="ion-arrow-right-b"></i>
					&nbsp;&nbsp; Présentation de LabTIC
				</h3>
			</div>
			<div class="panel-body">
				<?= $presentation_labtic ?>
			</div>
		</div>	

		<div class="panel panel-color panel-custom">
			<!-- Default panel contents -->
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="ion-arrow-right-b"></i>
					&nbsp;&nbsp; Thématique Générale de recherche
				</h3>
			</div>
			<div class="panel-body inner-padding">
				<?= $thematique ?>
			</div>
			<br>
		</div>

		<div class="panel panel-color panel-custom">
			<!-- Default panel contents -->
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="ion-arrow-right-b"></i>
					&nbsp;&nbsp; Mots-clés
				</h3>
			</div>
			<div class="panel-body inner-padding">
				<?= $mots_cles ?>
			</div>
			<br>
		</div>


		<div class="panel panel-color panel-custom">
			<!-- Default panel contents -->
			<div class="panel-heading">
				<h3 class="panel-title">
					<i class="ion-arrow-right-b"></i>
					&nbsp;&nbsp; Axes de recherche
				</h3>
			</div>
			<div class="panel-body inner-padding">
				<?= $axes_recherche ?>
			</div>
			<br>
		</div>

<?php
	require "inc/footer.php";
?>