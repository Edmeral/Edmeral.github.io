<?php
	require "inc/header.php";
	require "controllers/trombinoscope.php"
?>

<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<div class="row">
				<div class="col-lg-12">
					<h2 class="m-t-0 header-title"><b>Trombinoscope</b></h2>
					<div class="p-20">
						<div class="table-responsive">
							<h3>Membres permanents</h3>
							<?= $permanents ?>

							<h3>Doctorants</h3>
							<?= $non_perm ?>

							<h3>Anciens membres</h3>
							<?= $anciens ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>
