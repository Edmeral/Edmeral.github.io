<?php
	require "inc/header.php";
	require 'controllers/postes-enseignant.php' ;	
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Postes Enseignant</h1>
					<div class="row">
						<div class="col-md-2"></div>
						<div class="col-md-8">
							<table class="table">
								<thead>
									<tr>
										<th width="25%">Titre</th>
										<th width="50%">Description</th>
										<th width="20%">Date</th>
										<th width="5%"></th>
									</tr>
								</thead>
								<tbody>
									<?= $affichage ?>
								</tbody>
							</table>
						</div>
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>