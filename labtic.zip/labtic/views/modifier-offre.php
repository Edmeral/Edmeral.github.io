<?php
	require "inc/header.php";
	require "models/postes.php";
	$offre = get_offre($id);
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-border panel-custom">
			<div class="panel-heading">
				<h3 class="panel-title"></h3>
			</div>
			<div class="panel-body">
				<p>
					<h1>Modifier l'offre</h1>
									<?php
				if (isset($_SESSION['slim.flash']['success'])) echo '<div class="alert alert-success" role="alert">'.$_SESSION['slim.flash']['success'].'</div>';
				if (isset($_SESSION['slim.flash']['error'])) echo '<div class="alert alert-danger" role="alert">'.$_SESSION['slim.flash']['error'].'</div>';
				?>
					<br><br>
					<div class="col-md-2"></div>
					<div class="col-md-8">
						<form  class="form-horizontal" role="form" method="POST" action="/labtic/modifier-offre" enctype="multipart/form-data">
							<div class="form-group">
	                            <label class="col-md-2 control-label">Titre :</label>
	                                <div class="col-md-6">
	                                    <input type="text" class="form-control" name="titre" placeholder="Titre ..." value="<?= utf8_encode($offre['titre'])?>" required> 
	                                </div>
	                        </div>
	                        <div class="form-group">
			                        <label class="control-label col-md-2">Date :</label>
			                            <div class="col-md-6">
			                             	<input type="text" class="datepicker form-control" name="date_offre" placeholder="mm/dd/yyyy" value="<?= utf8_encode($offre['date_offre'])?>" id="datepicker" required>
			                			</div>
			                </div>
			                <div class="form-group">
	                                <label class="col-md-2 control-label">Description :</label>
	    								<div class="col-md-6">
	                                       	<textarea class="form-control" name="description" rows="5"><?= utf8_encode($offre['description'])?></textarea>
	                                    </div>
	                        </div>
			                <div class="form-group">
	                                <label class="col-md-2 control-label">Type :</label>
	    								<div class="col-md-6">
	                                       	<select class="form-control" name="type" required>
	                                       		<optgroup label="Postes">
	                                       			<option value="poste enseignant" <?php if($offre['type']=="poste enseignant") echo "selected"; ?> >Poste Enseignant</option>
	                                       			<option value="poste ingenieur" <?php if($offre['type']=="poste ingenieur") echo "selected"; ?>>Poste Ingenieur</option>
	                                       		</optgroup>
	                                       		<optgroup label="Sujets">
	                                       			<option value="sujet these" <?php if($offre['type']=="sujet these") echo "selected"; ?>>Sujet Thèse</option>
	                                       			<option value="sujet stage" <?php if($offre['type']=="sujet stage") echo "selected"; ?>>Sujet Stage</option>
	                                       		</optgroup>
	                                       	</select>
	                                    </div>
	                        </div>
	                    	<div class="form-group">
								<label class="col-md-2 control-label">Fichier:</label>
								<div class="col-md-6">

								
									<div class="fileupload	btn btn-default btn-custom btn-rounded waves-effect waves-light">
                                        <span>Modifier le fichier</span>
                                      <input type="file" class="upload" name="nom_fichier">
                                    </div>	
                                </div>
                            </div>                    	                        
							<div class="form-group">
	                        		<div class="col-md-3"></div>
	                        		<div class="col-md-3">
	                        			<button type="sumbit" class="btn btn-default btn-custom btn-rounded waves-effect waves-light">Modifier</button>
	                        		</div>								
									
                			</div>
                			<input type ="hidden" name="id" value="<?= $id ?>">
						</form>
					</div>
				</p>
			</div>
		</div>
	</div>
</div>

<?php
	require "inc/footer.php";
?>