	return window.Parsley;
}));
